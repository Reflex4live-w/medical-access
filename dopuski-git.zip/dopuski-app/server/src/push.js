import express from 'express';
import webpush from 'web-push';
import { db, getSetting, setSetting, appSettings, rowToEmp, EMP_SELECT } from './db.js';
import { buildSummary, isoOf, today, isBoss } from '../../shared/status.js';

/* ---------- VAPID: из env или генерим один раз и храним в БД ---------- */
let keys = process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY
  ? { publicKey: process.env.VAPID_PUBLIC_KEY, privateKey: process.env.VAPID_PRIVATE_KEY }
  : getSetting('vapid', null);
if (!keys) { keys = webpush.generateVAPIDKeys(); setSetting('vapid', keys); }
webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@example.com', keys.publicKey, keys.privateKey);

export const pushRouter = express.Router();

pushRouter.get('/key', (req, res) => res.json({ key: keys.publicKey }));
pushRouter.post('/subscribe', (req, res) => {
  const s = req.body?.subscription;
  if (!s?.endpoint || !s?.keys?.p256dh || !s?.keys?.auth || !/^https:\/\//.test(s.endpoint)) return res.status(400).json({ error: 'Кривая подписка' });
  db.prepare(`INSERT INTO push_subs(user_id, endpoint, p256dh, auth, ua) VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(endpoint) DO UPDATE SET user_id = excluded.user_id, p256dh = excluded.p256dh, auth = excluded.auth, ua = excluded.ua`)
    .run(req.user.id, s.endpoint, s.keys.p256dh, s.keys.auth, String(req.get('user-agent') || '').slice(0, 200));
  res.json({ ok: true });
});
pushRouter.post('/unsubscribe', (req, res) => {
  db.prepare('DELETE FROM push_subs WHERE endpoint = ? AND user_id = ?').run(String(req.body?.endpoint || ''), req.user.id);
  res.json({ ok: true });
});
pushRouter.post('/test', async (req, res, next) => {
  try {
    const summary = summaryFor(req.user.id) || { title: 'Всё чисто', body: 'Ни проблем, ни ближайших дней рождения.' };
    const sent = await sendToUser(req.user.id, summary);
    if (!sent) return res.status(400).json({ error: 'На этом аккаунте нет устройств с включёнными уведомлениями' });
    res.json({ ok: true, sent });
  } catch (e) { next(e); }
});

/* ---------- сводка для пользователя ---------- */
export function summaryFor(userId) {
  const u = db.prepare('SELECT id, role FROM users WHERE id = ? AND active = 1').get(userId);
  if (!u) return null;
  const locs = db.prepare('SELECT id, name FROM locations').all();
  const locName = Object.fromEntries(locs.map((l) => [l.id, l.name]));
  let rows = db.prepare(EMP_SELECT + ' WHERE e.archived = 0').all().map(rowToEmp);
  let showLoc = true;
  if (!isBoss(u.role)) {
    const mine = db.prepare('SELECT location_id FROM user_locations WHERE user_id = ?').all(u.id).map((x) => x.location_id);
    rows = rows.filter((e) => mine.includes(e.locationId));
    showLoc = mine.length > 1;
  }
  rows.forEach((e) => { e.locationName = locName[e.locationId] || ''; });
  return buildSummary(rows, appSettings(), { showLoc });
}

async function sendToUser(userId, { title, body }) {
  const subs = db.prepare('SELECT * FROM push_subs WHERE user_id = ?').all(userId);
  const payload = JSON.stringify({ title, body, tag: 'dopusk-daily', url: '/' });
  let ok = 0;
  await Promise.all(subs.map(async (s) => {
    try {
      await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, payload, { TTL: 6 * 3600, urgency: 'normal' });
      ok++;
    } catch (e) {
      if (e.statusCode === 404 || e.statusCode === 410) db.prepare('DELETE FROM push_subs WHERE id = ?').run(s.id);
      else console.warn('[push] ошибка отправки', e.statusCode || '', e.body || e.message);
    }
  }));
  return ok;
}

/* ---------- ежедневная рассылка ---------- */
function hhmm(d) { return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
let running = false;
async function tick() {
  if (running) return; running = true;
  try {
    const now = new Date(), t = hhmm(now), day = isoOf(today());
    // Шлём, если время уже наступило и сегодня ещё не слали (переживает перезапуск сервера).
    // Но не позже чем через 3 часа после заданного — чтобы не будить ночью после долгого простоя.
    const users = db.prepare(`SELECT u.id, u.notify_time FROM users u WHERE u.active = 1 AND u.notify_last != ?
      AND EXISTS (SELECT 1 FROM push_subs p WHERE p.user_id = u.id)`).all(day);
    for (const u of users) {
      if (t < u.notify_time) continue;
      const [h, m] = u.notify_time.split(':').map(Number);
      if ((now.getHours() * 60 + now.getMinutes()) - (h * 60 + m) > 180) { db.prepare('UPDATE users SET notify_last = ? WHERE id = ?').run(day, u.id); continue; }
      db.prepare('UPDATE users SET notify_last = ? WHERE id = ?').run(day, u.id);
      const s = summaryFor(u.id);
      if (s) await sendToUser(u.id, s);
    }
  } catch (e) { console.error('[push] tick', e); }
  finally { running = false; }
}
export function startScheduler() {
  setTimeout(tick, 5000);
  setInterval(tick, 60e3).unref();
}
