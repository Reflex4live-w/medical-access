import fs from 'node:fs';
import path from 'node:path';
import { db, DATA_DIR } from './db.js';

const DIR = path.join(DATA_DIR, 'backups');
const KEEP = Number(process.env.BACKUP_KEEP || 30);

export async function backupNow() {
  fs.mkdirSync(DIR, { recursive: true });
  const d = new Date();
  const name = `dopuski-${d.toISOString().slice(0, 10)}.db`;
  await db.backup(path.join(DIR, name));
  const files = fs.readdirSync(DIR).filter((f) => /^dopuski-\d{4}-\d{2}-\d{2}\.db$/.test(f)).sort();
  files.slice(0, Math.max(0, files.length - KEEP)).forEach((f) => fs.unlinkSync(path.join(DIR, f)));
  return name;
}

/** Раз в сутки (и при старте, если сегодня ещё не было) — копия базы в data/backups, храним KEEP штук. */
export function startBackups() {
  const run = () => {
    const name = `dopuski-${new Date().toISOString().slice(0, 10)}.db`;
    if (fs.existsSync(path.join(DIR, name))) return;
    backupNow().then((n) => console.log('[backup]', n)).catch((e) => console.error('[backup]', e));
  };
  setTimeout(run, 15e3);
  setInterval(run, 3600e3).unref();
}
