import express from 'express';
import crypto from 'node:crypto';
import { db, appSettings, setSetting, rowToEmp, EMP_SELECT, audit } from './db.js';
import {
  createSession, destroySession, killUserSessions, hashPassword, checkPassword, passwordProblem,
  requireUser, requireBoss, requireEditor, requireOwner, canLoc, loginBlocked, loginFailed, loginOk,
} from './auth.js';
import { validPos, validMode, isIsoDate, normKey, isoOf, today, isBoss, isRole, manageableRoles, hasLocations, ROLE_RANK } from '../../shared/status.js';
import { pushRouter } from './push.js';

export const api = express.Router();

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = (msg) => new HttpError(400, msg);
const forbidden = (msg = 'Нет доступа к этой точке') => new HttpError(403, msg);
const notFound = (msg = 'Не найдено') => new HttpError(404, msg);
const wrap = (fn) => (req, res, next) => { try { const r = fn(req, res, next); if (r && r.catch) r.catch(next); } catch (e) { next(e); } };

const str = (v, max = 300) => String(v ?? '').trim().slice(0, max);
const uid = () => 'e' + Date.now().toString(36) + crypto.randomBytes(4).toString('hex');

/* ================= auth ================= */
api.post('/auth/login', wrap((req, res) => {
  const login = str(req.body?.login, 64), password = String(req.body?.password ?? '');
  const key = (req.ip || '') + '|' + login.toLowerCase();
  const wait = loginBlocked(key);
  if (wait) throw new HttpError(429, `Слишком много попыток. Попробуй через ${wait} мин.`);
  const u = db.prepare('SELECT * FROM users WHERE login = ?').get(login);
  if (!u || !u.active || !checkPassword(password, u.pass_hash)) { loginFailed(key); throw new HttpError(401, 'Неверный логин или пароль'); }
  loginOk(key);
  db.prepare("UPDATE users SET last_login = datetime('now') WHERE id = ?").run(u.id);
  createSession(res, u.id, req.get('user-agent'));
  res.json({ ok: true });
}));
api.post('/auth/logout', (req, res) => { destroySession(req, res); res.json({ ok: true }); });

/* ================= me ================= */
function visibleLocations(user) {
  const all = db.prepare('SELECT id, name, sort FROM locations ORDER BY sort, id').all();
  return isBoss(user.role) ? all : all.filter((l) => user.locationIds.includes(l.id));
}
api.get('/me', requireUser, (req, res) => {
  const u = req.user;
  res.json({
    user: { id: u.id, login: u.login, name: u.name, role: u.role, notifyTime: u.notifyTime, locationIds: u.locationIds },
    locations: visibleLocations(u),
    settings: appSettings(),
  });
});
api.patch('/me', requireUser, wrap((req, res) => {
  const b = req.body || {};
  if (b.notifyTime !== undefined) {
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(b.notifyTime)) throw bad('Неверное время');
    db.prepare("UPDATE users SET notify_time = ?, notify_last = '' WHERE id = ?").run(b.notifyTime, req.user.id);
  }
  if (b.name !== undefined) db.prepare('UPDATE users SET name = ? WHERE id = ?').run(str(b.name, 80), req.user.id);
  res.json({ ok: true });
}));
api.post('/me/password', requireUser, wrap((req, res) => {
  const { oldPassword, newPassword } = req.body || {};
  const u = db.prepare('SELECT pass_hash FROM users WHERE id = ?').get(req.user.id);
  if (!checkPassword(String(oldPassword ?? ''), u.pass_hash)) throw bad('Старый пароль не подходит');
  const p = passwordProblem(newPassword); if (p) throw bad(p);
  db.prepare('UPDATE users SET pass_hash = ? WHERE id = ?').run(hashPassword(newPassword), req.user.id);
  killUserSessions(req.user.id, req);
  res.json({ ok: true });
}));

/* ================= employees ================= */
function scopeWhere(user) {
  if (isBoss(user.role)) return { sql: '', args: [] };
  if (!user.locationIds.length) return { sql: ' WHERE 0', args: [] };
  return { sql: ` WHERE e.location_id IN (${user.locationIds.map(() => '?').join(',')})`, args: user.locationIds };
}
function getEmp(id) { const r = db.prepare(EMP_SELECT + ' WHERE e.id = ?').get(id); return r ? rowToEmp(r) : null; }
function getEmpScoped(user, id) {
  const e = getEmp(id);
  if (!e) throw notFound('Сотрудник не найден');
  if (!canLoc(user, e.locationId)) throw notFound('Сотрудник не найден');
  return e;
}
function locExists(id) { return !!db.prepare('SELECT 1 FROM locations WHERE id = ?').get(id); }

/** Проверка и нормализация полей сотрудника. Возвращает объект колонок для БД. */
function empColumns(b, { partial }) {
  const c = {};
  const has = (k) => b[k] !== undefined;
  if (has('fio') || !partial) { const v = str(b.fio, 120); if (!v) throw bad('Впиши ФИО'); c.fio = v; }
  if (has('position') || !partial) { const v = b.position || ''; if (v && !validPos(v)) throw bad('Неизвестная должность'); c.position = v; }
  if (has('phone') || !partial) c.phone = str(b.phone, 40);
  if (has('note') || !partial) c.note = str(b.note, 500);
  for (const [k, col] of [['birthday', 'birthday'], ['firstShift', 'first_shift']]) {
    if (has(k) || !partial) { const v = b[k] || ''; if (v && !isIsoDate(v)) throw bad('Неверная дата'); c[col] = v; }
  }
  for (const k of ['med', 'holo']) {
    if (has(k) || !partial) {
      const d = b[k] || {}; const mode = d.mode || 'date', date = d.date || '';
      if (!validMode(mode)) throw bad('Неверный статус документа');
      if (date && !isIsoDate(date)) throw bad('Неверная дата документа');
      c[k + '_mode'] = mode; c[k + '_date'] = date;
    }
  }
  if (has('locationId') || !partial) {
    const v = b.locationId == null || b.locationId === '' ? null : Number(b.locationId);
    if (v != null && !locExists(v)) throw bad('Точка не найдена');
    c.location_id = v;
  }
  return c;
}
function diff(before, after) {
  const d = {};
  const flat = (e) => ({ fio: e.fio, position: e.position, phone: e.phone, note: e.note, birthday: e.birthday, firstShift: e.firstShift, locationId: e.locationId,
    med: e.med.mode === 'date' ? e.med.date : e.med.mode, holo: e.holo.mode === 'date' ? e.holo.date : e.holo.mode });
  const a = flat(before), b = flat(after);
  for (const k in a) if (a[k] !== b[k]) d[k] = [a[k], b[k]];
  return d;
}

api.get('/employees', requireUser, (req, res) => {
  const w = scopeWhere(req.user);
  const rows = db.prepare(EMP_SELECT + w.sql + ' ORDER BY e.fio').all(...w.args);
  res.json({ employees: rows.map(rowToEmp), serverTime: new Date().toISOString() });
});

api.post('/employees', requireEditor, wrap((req, res) => {
  const b = req.body || {};
  const c = empColumns(b, { partial: false });
  if (!isBoss(req.user.role)) {
    if (c.location_id == null && req.user.locationIds.length === 1) c.location_id = req.user.locationIds[0];
    if (!canLoc(req.user, c.location_id)) throw forbidden('Выбери свою точку');
  }
  const id = uid();
  const cols = Object.keys(c);
  db.prepare(`INSERT INTO employees(id, ${cols.join(',')}, updated_by) VALUES (?, ${cols.map(() => '?').join(',')}, ?)`)
    .run(id, ...cols.map((k) => c[k]), req.user.id);
  audit(req.user.id, id, 'create', { fio: c.fio });
  res.status(201).json({ employee: getEmp(id) });
}));

api.patch('/employees/:id', requireEditor, wrap((req, res) => {
  const before = getEmpScoped(req.user, req.params.id);
  if (before.archived) throw bad('Сотрудник в архиве — сначала верни его');
  const c = empColumns(req.body || {}, { partial: true });
  if ('location_id' in c && !canLoc(req.user, c.location_id)) throw forbidden('Перевести можно только на свою точку');
  const cols = Object.keys(c);
  if (!cols.length) return res.json({ employee: before });
  db.prepare(`UPDATE employees SET ${cols.map((k) => k + ' = ?').join(', ')}, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), updated_by = ? WHERE id = ?`)
    .run(...cols.map((k) => c[k]), req.user.id, before.id);
  const after = getEmp(before.id);
  const d = diff(before, after);
  if (Object.keys(d).length) {
    // правки одного человека по одному сотруднику в течение 3 минут склеиваем в одну запись журнала
    const last = db.prepare(`SELECT id, details FROM audit WHERE employee_id = ? AND user_id = ? AND action = 'update'
      AND at > strftime('%Y-%m-%dT%H:%M:%fZ','now','-3 minutes') ORDER BY id DESC LIMIT 1`).get(before.id, req.user.id);
    const isLast = last && db.prepare('SELECT MAX(id) m FROM audit WHERE employee_id = ?').get(before.id).m === last.id;
    if (isLast) {
      const prev = JSON.parse(last.details || '{}');
      for (const k in d) prev[k] = prev[k] ? [prev[k][0], d[k][1]] : d[k];
      for (const k in prev) if (prev[k][0] === prev[k][1]) delete prev[k];
      if (Object.keys(prev).length) db.prepare("UPDATE audit SET details = ?, at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(JSON.stringify(prev), last.id);
      else db.prepare('DELETE FROM audit WHERE id = ?').run(last.id);
    } else audit(req.user.id, before.id, 'update', d);
  }
  res.json({ employee: after });
}));

api.post('/employees/:id/archive', requireEditor, wrap((req, res) => {
  const e = getEmpScoped(req.user, req.params.id);
  const at = String(req.body?.date || '') || isoOf(today());
  if (!isIsoDate(at)) throw bad('Неверная дата');
  db.prepare("UPDATE employees SET archived = 1, archived_at = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), updated_by = ? WHERE id = ?").run(at, req.user.id, e.id);
  audit(req.user.id, e.id, 'archive', { fio: e.fio });
  res.json({ employee: getEmp(e.id) });
}));
api.post('/employees/:id/restore', requireEditor, wrap((req, res) => {
  const e = getEmpScoped(req.user, req.params.id);
  db.prepare("UPDATE employees SET archived = 0, archived_at = '', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), updated_by = ? WHERE id = ?").run(req.user.id, e.id);
  audit(req.user.id, e.id, 'restore', { fio: e.fio });
  res.json({ employee: getEmp(e.id) });
}));
api.delete('/employees/:id', requireBoss, wrap((req, res) => {
  const e = getEmpScoped(req.user, req.params.id);
  if (!e.archived) throw bad('Удалить навсегда можно только из архива');
  db.prepare('DELETE FROM employees WHERE id = ?').run(e.id);
  audit(req.user.id, e.id, 'purge', e); // снимок — чтобы можно было восстановить вручную
  res.json({ ok: true });
}));
api.get('/employees/:id/history', requireUser, wrap((req, res) => {
  const e = getEmpScoped(req.user, req.params.id);
  const rows = db.prepare(`SELECT a.at, a.action, a.details, u.name AS user_name, u.login FROM audit a LEFT JOIN users u ON u.id = a.user_id
    WHERE a.employee_id = ? ORDER BY a.id DESC LIMIT 50`).all(e.id);
  res.json({ history: rows.map((r) => ({ at: r.at, action: r.action, user: r.user_name || r.login || '—', details: r.details ? JSON.parse(r.details) : null })) });
}));

/* ================= locations (admin) ================= */
api.get('/locations', requireUser, (req, res) => res.json({ locations: visibleLocations(req.user) }));
api.post('/locations', requireBoss, wrap((req, res) => {
  const name = str(req.body?.name, 80); if (!name) throw bad('Введи название');
  if (db.prepare('SELECT 1 FROM locations WHERE name = ?').get(name)) throw bad('Такая точка уже есть');
  const sort = (db.prepare('SELECT MAX(sort) m FROM locations').get().m ?? -1) + 1;
  const r = db.prepare('INSERT INTO locations(name, sort) VALUES (?, ?)').run(name, sort);
  audit(req.user.id, null, 'location.create', { name });
  res.status(201).json({ location: { id: r.lastInsertRowid, name, sort } });
}));
api.patch('/locations/:id', requireBoss, wrap((req, res) => {
  const id = Number(req.params.id), name = str(req.body?.name, 80);
  const old = db.prepare('SELECT * FROM locations WHERE id = ?').get(id); if (!old) throw notFound();
  if (!name) throw bad('Введи название');
  if (db.prepare('SELECT 1 FROM locations WHERE name = ? AND id != ?').get(name, id)) throw bad('Такая точка уже есть');
  db.prepare('UPDATE locations SET name = ? WHERE id = ?').run(name, id);
  audit(req.user.id, null, 'location.rename', { from: old.name, to: name });
  res.json({ ok: true });
}));
api.delete('/locations/:id', requireBoss, wrap((req, res) => {
  const id = Number(req.params.id);
  const old = db.prepare('SELECT * FROM locations WHERE id = ?').get(id); if (!old) throw notFound();
  db.prepare('DELETE FROM locations WHERE id = ?').run(id); // сотрудники остаются без точки
  audit(req.user.id, null, 'location.delete', { name: old.name });
  res.json({ ok: true });
}));

/* ================= users (админ и ТУ) ================= */
function listUsers() {
  const users = db.prepare('SELECT id, login, name, role, active, notify_time, created_at, last_login FROM users').all();
  const links = db.prepare('SELECT user_id, location_id FROM user_locations').all();
  const pushes = db.prepare('SELECT user_id, COUNT(*) n FROM push_subs GROUP BY user_id').all();
  return users
    .sort((a, b) => (ROLE_RANK[b.role] - ROLE_RANK[a.role]) || (a.name || a.login).localeCompare(b.name || b.login, 'ru'))
    .map((u) => ({
      id: u.id, login: u.login, name: u.name, role: u.role, active: !!u.active, notifyTime: u.notify_time,
      createdAt: u.created_at, lastLogin: u.last_login,
      locationIds: links.filter((l) => l.user_id === u.id).map((l) => l.location_id),
      pushDevices: pushes.find((p) => p.user_id === u.id)?.n || 0,
    }));
}
function setUserLocs(userId, ids) {
  if (!Array.isArray(ids)) throw bad('Неверный список точек');
  const clean = [...new Set(ids.map(Number))];
  for (const l of clean) if (!locExists(l)) throw bad('Точка не найдена');
  db.prepare('DELETE FROM user_locations WHERE user_id = ?').run(userId);
  const ins = db.prepare('INSERT INTO user_locations(user_id, location_id) VALUES (?, ?)');
  clean.forEach((l) => ins.run(userId, l));
}
/** Можно ли текущему пользователю трогать аккаунт с ролью targetRole */
function canManage(me, targetRole) { return manageableRoles(me.role).includes(targetRole); }
function checkRole(me, role) {
  if (!isRole(role)) throw bad('Неизвестная роль');
  if (role === 'admin') throw forbidden('Админ в системе только один');
  if (!canManage(me, role)) throw forbidden('Эту роль ты назначать не можешь');
}

api.get('/users', requireBoss, (req, res) => res.json({ users: listUsers() }));
api.post('/users', requireBoss, wrap((req, res) => {
  const b = req.body || {};
  const login = str(b.login, 64), name = str(b.name, 80), role = String(b.role || '');
  checkRole(req.user, role);
  if (!/^[a-zA-Z0-9._-]{3,64}$/.test(login)) throw bad('Логин: латиница, цифры, . _ - (от 3 символов)');
  if (db.prepare('SELECT 1 FROM users WHERE login = ?').get(login)) throw bad('Такой логин уже занят');
  const p = passwordProblem(b.password); if (p) throw bad(p);
  if (hasLocations(role) && !(b.locationIds || []).length) throw bad('Отметь хотя бы одну точку');
  db.transaction(() => {
    const r = db.prepare('INSERT INTO users(login, name, pass_hash, role) VALUES (?, ?, ?, ?)').run(login, name, hashPassword(b.password), role);
    if (hasLocations(role)) setUserLocs(r.lastInsertRowid, b.locationIds);
    audit(req.user.id, null, 'user.create', { login, role });
  })();
  res.status(201).json({ users: listUsers() });
}));
api.patch('/users/:id', requireBoss, wrap((req, res) => {
  const id = Number(req.params.id), b = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id); if (!u) throw notFound();
  const self = id === req.user.id;
  // себе можно только имя; чужих — только тех, кто ниже по роли
  if (self) {
    if (Object.keys(b).some((k) => k !== 'name')) throw forbidden('Свою роль, точки и доступ менять нельзя. Пароль — в «Мой аккаунт»');
  } else if (!canManage(req.user, u.role)) throw forbidden('Этого пользователя ты менять не можешь');
  db.transaction(() => {
    if (b.name !== undefined) db.prepare('UPDATE users SET name = ? WHERE id = ?').run(str(b.name, 80), id);
    let role = u.role;
    if (b.role !== undefined && b.role !== u.role) {
      checkRole(req.user, b.role); role = b.role;
      db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, id);
      if (!hasLocations(role)) db.prepare('DELETE FROM user_locations WHERE user_id = ?').run(id);
    }
    if (b.locationIds !== undefined) {
      if (!hasLocations(role)) throw bad('Этой роли точки не назначаются — она видит все');
      setUserLocs(id, b.locationIds);
    }
    if (b.active !== undefined) {
      db.prepare('UPDATE users SET active = ? WHERE id = ?').run(b.active ? 1 : 0, id);
      if (!b.active) killUserSessions(id);
    }
    if (b.password !== undefined) {
      const p = passwordProblem(b.password); if (p) throw bad(p);
      db.prepare('UPDATE users SET pass_hash = ? WHERE id = ?').run(hashPassword(b.password), id);
      killUserSessions(id);
    }
    audit(req.user.id, null, 'user.update', { login: u.login, fields: Object.keys(b).filter((k) => k !== 'password').concat(b.password ? ['пароль'] : []) });
  })();
  res.json({ users: listUsers() });
}));
api.delete('/users/:id', requireBoss, wrap((req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) throw bad('Нельзя удалить самого себя');
  const u = db.prepare('SELECT login, role FROM users WHERE id = ?').get(id); if (!u) throw notFound();
  if (!canManage(req.user, u.role)) throw forbidden('Этого пользователя ты удалить не можешь');
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  audit(req.user.id, null, 'user.delete', { login: u.login });
  res.json({ users: listUsers() });
}));

/* ================= settings (admin) ================= */
api.patch('/settings', requireBoss, wrap((req, res) => {
  const b = req.body || {};
  const num = (v, max) => { const n = parseInt(v, 10); if (isNaN(n) || n < 0 || n > max) throw bad('Неверное число'); return n; };
  if (b.warnDays !== undefined) setSetting('warnDays', num(b.warnDays, 365));
  if (b.bdayDays !== undefined) setSetting('bdayDays', num(b.bdayDays, 90));
  res.json({ settings: appSettings() });
}));

/* ================= audit (admin) ================= */
api.get('/audit', requireOwner, (req, res) => {
  const limit = Math.min(500, Number(req.query.limit) || 200);
  const rows = db.prepare(`SELECT a.at, a.action, a.details, a.employee_id, u.name AS user_name, u.login, e.fio
    FROM audit a LEFT JOIN users u ON u.id = a.user_id LEFT JOIN employees e ON e.id = a.employee_id ORDER BY a.id DESC LIMIT ?`).all(limit);
  res.json({ audit: rows.map((r) => ({ at: r.at, action: r.action, user: r.user_name || r.login || '—', fio: r.fio || null, details: r.details ? JSON.parse(r.details) : null })) });
});

/* ================= import / export (admin) ================= */
api.get('/export', requireBoss, (req, res) => {
  const locs = db.prepare('SELECT id, name FROM locations ORDER BY sort, id').all();
  const byId = Object.fromEntries(locs.map((l) => [l.id, l.name]));
  const emps = db.prepare(EMP_SELECT).all().map(rowToEmp).map((e) => {
    const { locationId, updatedBy, ...rest } = e; return { ...rest, location: byId[locationId] || '' };
  });
  const payload = { app: 'med-hologram-tracker', version: 4, exportedAt: new Date().toISOString(), locations: locs.map((l) => l.name), employees: emps };
  res.setHeader('Content-Disposition', `attachment; filename="dopuski-${new Date().toISOString().slice(0, 10)}.json"`);
  res.json(payload);
});

function pickDoc(a, b, bNewer) {
  const ad = a.mode === 'date' && !!a.date, bd = b.mode === 'date' && !!b.date;
  if (ad && bd) return b.date > a.date ? b : a;
  if (bd && !ad) return b;
  if (bNewer && b.mode !== 'date') return b;
  if (a.mode === 'date' && !a.date && b.mode !== 'date') return b;
  return a;
}
api.post('/import', requireBoss, wrap((req, res) => {
  const b = req.body || {};
  const arr = Array.isArray(b.data) ? b.data : Array.isArray(b.data?.employees) ? b.data.employees : null;
  if (!arr) throw bad('Не тот формат файла');
  if (arr.length > 5000) throw bad('Слишком много записей');
  const mode = b.mode === 'replace' ? 'replace' : 'merge';
  const fileLocs = Array.isArray(b.data?.locations) ? b.data.locations : [];

  const stats = { added: 0, updated: 0, skipped: 0 };
  db.transaction(() => {
    const locId = (name) => {
      name = str(name, 80); if (!name) return null;
      const r = db.prepare('SELECT id FROM locations WHERE name = ?').get(name);
      if (r) return r.id;
      const sort = (db.prepare('SELECT MAX(sort) m FROM locations').get().m ?? -1) + 1;
      return Number(db.prepare('INSERT INTO locations(name, sort) VALUES (?, ?)').run(name, sort).lastInsertRowid);
    };
    fileLocs.forEach(locId);
    if (mode === 'replace') db.prepare('DELETE FROM employees').run();

    const existing = new Map();
    db.prepare(EMP_SELECT).all().map(rowToEmp).forEach((e) => existing.set(normKey(e.fio), e));

    for (const raw of arr) {
      const x = raw || {};
      const fio = str(x.fio, 120); if (!fio) { stats.skipped++; continue; }
      const doc = (d) => { d = d || {}; const m = validMode(d.mode) ? d.mode : 'date'; return { mode: m, date: isIsoDate(d.date) ? d.date : '' }; };
      const inc = {
        fio, position: validPos(x.position) ? x.position : (x.trainee ? 'trainee' : ''),
        phone: str(x.phone, 40), note: str(x.note, 500),
        birthday: isIsoDate(x.birthday) ? x.birthday : '', firstShift: isIsoDate(x.firstShift) ? x.firstShift : '',
        med: doc(x.med), holo: doc(x.holo), locationId: x.location ? locId(x.location) : null,
        archived: !!x.archived, archivedAt: isIsoDate(x.archivedAt) ? x.archivedAt : '', updatedAt: str(x.updatedAt, 40),
      };
      const cur = existing.get(normKey(fio));
      if (cur) {
        const newer = (inc.updatedAt || '') > (cur.updatedAt || '');
        const set = {};
        for (const [k, col] of [['position', 'position'], ['phone', 'phone'], ['note', 'note'], ['birthday', 'birthday'], ['firstShift', 'first_shift']]) {
          if (inc[k] && inc[k] !== cur[k] && (newer || !cur[k])) set[col] = inc[k];
        }
        if (inc.locationId != null && inc.locationId !== cur.locationId && (newer || cur.locationId == null)) set.location_id = inc.locationId;
        for (const k of ['med', 'holo']) {
          const p = pickDoc(cur[k], inc[k], newer);
          if (p.mode !== cur[k].mode || p.date !== cur[k].date) { set[k + '_mode'] = p.mode; set[k + '_date'] = p.date; }
        }
        if (newer && inc.archived !== cur.archived) { set.archived = inc.archived ? 1 : 0; set.archived_at = inc.archivedAt; }
        const cols = Object.keys(set);
        if (cols.length) {
          db.prepare(`UPDATE employees SET ${cols.map((k) => k + ' = ?').join(', ')}, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), updated_by = ? WHERE id = ?`)
            .run(...cols.map((k) => set[k]), req.user.id, cur.id);
          stats.updated++;
        }
      } else {
        const id = uid();
        db.prepare(`INSERT INTO employees(id, location_id, fio, position, phone, note, birthday, first_shift, med_mode, med_date, holo_mode, holo_date, archived, archived_at, updated_by)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id, inc.locationId, inc.fio, inc.position, inc.phone, inc.note, inc.birthday, inc.firstShift,
          inc.med.mode, inc.med.date, inc.holo.mode, inc.holo.date, inc.archived ? 1 : 0, inc.archivedAt, req.user.id);
        existing.set(normKey(fio), { ...inc, id });
        stats.added++;
      }
    }
    audit(req.user.id, null, 'import', { mode, ...stats });
  })();
  res.json(stats);
}));

/* ================= push ================= */
api.use('/push', requireUser, pushRouter);

/* ================= errors ================= */
api.use((req, res) => res.status(404).json({ error: 'Нет такого адреса' }));
// eslint-disable-next-line no-unused-vars
api.use((err, req, res, next) => {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'Файл слишком большой' });
  if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'Кривой JSON' });
  console.error(err);
  res.status(500).json({ error: 'Ошибка сервера' });
});
