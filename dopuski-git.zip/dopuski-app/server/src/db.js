import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

export const DATA_DIR = process.env.DATA_DIR || path.resolve('data');
fs.mkdirSync(DATA_DIR, { recursive: true });

export const db = new Database(path.join(DATA_DIR, 'dopuski.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

const MIGRATIONS = [
  // 1 — базовая схема
  `
  CREATE TABLE locations (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    sort INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    login TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT NOT NULL DEFAULT '',
    pass_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin','manager')),
    active INTEGER NOT NULL DEFAULT 1,
    notify_time TEXT NOT NULL DEFAULT '12:00',
    notify_last TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    last_login TEXT
  );
  CREATE TABLE user_locations (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, location_id)
  );
  CREATE TABLE sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    expires_at INTEGER NOT NULL,
    ua TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE employees (
    id TEXT PRIMARY KEY,
    location_id INTEGER REFERENCES locations(id) ON DELETE SET NULL,
    fio TEXT NOT NULL DEFAULT '',
    position TEXT NOT NULL DEFAULT '',
    phone TEXT NOT NULL DEFAULT '',
    note TEXT NOT NULL DEFAULT '',
    birthday TEXT NOT NULL DEFAULT '',
    first_shift TEXT NOT NULL DEFAULT '',
    med_mode TEXT NOT NULL DEFAULT 'date',
    med_date TEXT NOT NULL DEFAULT '',
    holo_mode TEXT NOT NULL DEFAULT 'date',
    holo_date TEXT NOT NULL DEFAULT '',
    archived INTEGER NOT NULL DEFAULT 0,
    archived_at TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL
  );
  CREATE INDEX employees_loc ON employees(location_id);
  CREATE TABLE audit (
    id INTEGER PRIMARY KEY,
    at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    employee_id TEXT,
    action TEXT NOT NULL,
    details TEXT NOT NULL DEFAULT ''
  );
  CREATE INDEX audit_at ON audit(at);
  CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  CREATE TABLE push_subs (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    endpoint TEXT NOT NULL UNIQUE,
    p256dh TEXT NOT NULL,
    auth TEXT NOT NULL,
    ua TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  `,
  // 2 — роли: админ / ТУ / СМС / наблюдатель (снимаем старый CHECK)
  `
  CREATE TABLE users_new (
    id INTEGER PRIMARY KEY,
    login TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT NOT NULL DEFAULT '',
    pass_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin','territorial','manager','viewer')),
    active INTEGER NOT NULL DEFAULT 1,
    notify_time TEXT NOT NULL DEFAULT '12:00',
    notify_last TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    last_login TEXT
  );
  INSERT INTO users_new SELECT id, login, name, pass_hash, role, active, notify_time, notify_last, created_at, last_login FROM users;
  DROP TABLE users;
  ALTER TABLE users_new RENAME TO users;
  `,
];

const ver = db.pragma('user_version', { simple: true });
if (ver < MIGRATIONS.length) {
  db.pragma('foreign_keys = OFF'); // пересоздание таблиц не должно каскадно чистить связи
  for (let i = ver; i < MIGRATIONS.length; i++) {
    db.transaction(() => { db.exec(MIGRATIONS[i]); db.pragma('user_version = ' + (i + 1)); })();
  }
  const bad = db.pragma('foreign_key_check');
  if (bad.length) console.warn('[db] foreign_key_check:', bad);
  db.pragma('foreign_keys = ON');
}


/* ---------- settings ---------- */
const getSet = db.prepare('SELECT value FROM settings WHERE key = ?');
const putSet = db.prepare('INSERT INTO settings(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
export function getSetting(k, def) { const r = getSet.get(k); return r ? JSON.parse(r.value) : def; }
export function setSetting(k, v) { putSet.run(k, JSON.stringify(v)); }
export function appSettings() {
  return { warnDays: getSetting('warnDays', 14), bdayDays: getSetting('bdayDays', 7) };
}

/* ---------- employees mapping ---------- */
export function rowToEmp(r) {
  return {
    id: r.id, locationId: r.location_id, fio: r.fio, position: r.position, phone: r.phone, note: r.note,
    birthday: r.birthday, firstShift: r.first_shift,
    med: { mode: r.med_mode, date: r.med_date }, holo: { mode: r.holo_mode, date: r.holo_date },
    archived: !!r.archived, archivedAt: r.archived_at, updatedAt: r.updated_at,
    updatedBy: r.updated_by_name ?? null,
  };
}
export const EMP_SELECT = `SELECT e.*, u.name AS updated_by_name FROM employees e LEFT JOIN users u ON u.id = e.updated_by`;

export function audit(userId, employeeId, action, details) {
  db.prepare('INSERT INTO audit(user_id, employee_id, action, details) VALUES (?, ?, ?, ?)')
    .run(userId ?? null, employeeId ?? null, action, details ? JSON.stringify(details) : '');
}
