// Служебные команды:
//   node src/cli.js passwd <login> <новый_пароль>   — сбросить пароль (и включить аккаунт)
//   node src/cli.js admin  <login> <пароль> [имя]   — создать админа (только если его нет)
//   node src/cli.js users                           — список пользователей
import { db } from './db.js';
import { hashPassword, passwordProblem } from './auth.js';

const [cmd, login, pass, ...rest] = process.argv.slice(2);
const die = (m) => { console.error(m); process.exit(1); };

if (cmd === 'passwd') {
  if (!login || !pass) die('Использование: passwd <login> <пароль>');
  const p = passwordProblem(pass); if (p) die(p);
  const r = db.prepare('UPDATE users SET pass_hash = ?, active = 1 WHERE login = ?').run(hashPassword(pass), login);
  if (!r.changes) die('Нет такого пользователя');
  db.prepare('DELETE FROM sessions WHERE user_id = (SELECT id FROM users WHERE login = ?)').run(login);
  console.log('Пароль обновлён');
} else if (cmd === 'admin') {
  if (!login || !pass) die('Использование: admin <login> <пароль> [имя]');
  const p = passwordProblem(pass); if (p) die(p);
  const ex = db.prepare("SELECT login FROM users WHERE role = 'admin'").get();
  if (ex) die(`Админ уже есть (${ex.login}) — он в системе один. Сбросить ему пароль: passwd ${ex.login} <пароль>`);
  db.prepare("INSERT INTO users(login, name, pass_hash, role) VALUES (?, ?, ?, 'admin')").run(login, rest.join(' ') || login, hashPassword(pass));
  console.log('Админ создан');
} else if (cmd === 'users') {
  console.table(db.prepare('SELECT id, login, name, role, active, last_login FROM users').all());
} else {
  die('Команды: passwd | admin | users');
}
