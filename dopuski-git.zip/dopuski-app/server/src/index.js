import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { db, DATA_DIR } from './db.js';
import { loadUser, hashPassword } from './auth.js';
import { api } from './api.js';
import { startScheduler } from './push.js';
import { startBackups } from './backup.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8080);
const WEB_DIR = process.env.WEB_DIR || path.resolve(__dirname, '../../web/dist');

/* ---------- первый админ ---------- */
const nUsers = db.prepare('SELECT COUNT(*) n FROM users').get().n;
if (!nUsers) {
  const login = process.env.ADMIN_LOGIN || 'admin';
  const pass = process.env.ADMIN_PASSWORD;
  if (!pass || pass.length < 6) {
    console.error('\n[!] В базе нет пользователей. Задай ADMIN_PASSWORD (минимум 6 символов) в .env и перезапусти.\n');
    process.exit(1);
  }
  db.prepare("INSERT INTO users(login, name, pass_hash, role) VALUES (?, ?, ?, 'admin')").run(login, process.env.ADMIN_NAME || 'Администратор', hashPassword(pass));
  console.log(`[init] создан админ «${login}»`);
}

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', process.env.TRUST_PROXY ?? 'loopback, uniquelocal');

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

/* ---------- API ---------- */
app.use('/api', express.json({ limit: '5mb' }), cookieParser(), loadUser, (req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  // защита от CSRF: все изменяющие запросы — только JSON с нашим заголовком
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && req.get('x-requested-with') !== 'dopuski') {
    return res.status(403).json({ error: 'Запрос отклонён' });
  }
  next();
}, api);

/* ---------- фронт ---------- */
if (fs.existsSync(WEB_DIR)) {
  app.use('/assets', express.static(path.join(WEB_DIR, 'assets'), { immutable: true, maxAge: '1y' }));
  app.use(express.static(WEB_DIR, {
    index: false,
    setHeaders: (res, p) => { if (/sw\.js$|\.webmanifest$/.test(p)) res.setHeader('Cache-Control', 'no-cache'); },
  }));
  app.get('*', (req, res) => { res.setHeader('Cache-Control', 'no-cache'); res.sendFile(path.join(WEB_DIR, 'index.html')); });
} else {
  console.warn('[web] сборка фронта не найдена:', WEB_DIR);
}

startScheduler();
startBackups();
app.listen(PORT, () => console.log(`[http] слушаю :${PORT}, данные в ${DATA_DIR}, TZ=${process.env.TZ || Intl.DateTimeFormat().resolvedOptions().timeZone}`));

for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { try { db.close(); } catch {} process.exit(0); });
