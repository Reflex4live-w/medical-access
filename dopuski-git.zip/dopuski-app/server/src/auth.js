import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import { db } from './db.js';
import { isBoss, canEditRole } from '../../shared/status.js';

export const COOKIE = 'dsid';
const TTL_MS = 30 * 24 * 3600 * 1000; // 30 дней, продлевается при активности
const SECURE = process.env.COOKIE_SECURE ? process.env.COOKIE_SECURE === '1' : process.env.NODE_ENV === 'production';

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

export function hashPassword(p) { return bcrypt.hashSync(p, 10); }
export function checkPassword(p, h) { return bcrypt.compareSync(p, h); }
export function passwordProblem(p) {
  if (typeof p !== 'string' || p.length < 6) return 'Пароль — минимум 6 символов';
  if (p.length > 200) return 'Слишком длинный пароль';
  return null;
}

export function createSession(res, userId, ua) {
  const token = crypto.randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions(token_hash, user_id, expires_at, ua) VALUES (?, ?, ?, ?)')
    .run(sha(token), userId, Date.now() + TTL_MS, String(ua || '').slice(0, 200));
  res.cookie(COOKIE, token, { httpOnly: true, sameSite: 'lax', secure: SECURE, maxAge: TTL_MS, path: '/' });
}
export function destroySession(req, res) {
  const t = req.cookies?.[COOKIE];
  if (t) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha(t));
  res.clearCookie(COOKIE, { path: '/' });
}
export function killUserSessions(userId, exceptReq) {
  const keep = exceptReq?.cookies?.[COOKIE] ? sha(exceptReq.cookies[COOKIE]) : '';
  db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?').run(userId, keep);
}

const selSession = db.prepare(`SELECT s.token_hash, s.expires_at, u.id, u.login, u.name, u.role, u.active, u.notify_time
  FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`);
const bump = db.prepare('UPDATE sessions SET expires_at = ? WHERE token_hash = ?');
const selUserLocs = db.prepare('SELECT location_id FROM user_locations WHERE user_id = ?');

export function loadUser(req, res, next) {
  const t = req.cookies?.[COOKIE];
  if (t) {
    const r = selSession.get(sha(t));
    if (r && r.active && r.expires_at > Date.now()) {
      // продлеваем не чаще раза в час
      if (r.expires_at - Date.now() < TTL_MS - 3600e3) {
        bump.run(Date.now() + TTL_MS, r.token_hash);
        res.cookie(COOKIE, t, { httpOnly: true, sameSite: 'lax', secure: SECURE, maxAge: TTL_MS, path: '/' });
      }
      req.user = {
        id: r.id, login: r.login, name: r.name, role: r.role, notifyTime: r.notify_time,
        locationIds: isBoss(r.role) ? null : selUserLocs.all(r.id).map((x) => x.location_id),
      };
    } else if (r) {
      db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(r.token_hash);
    }
  }
  next();
}

export function requireUser(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Нужно войти' });
  next();
}
/** Админ или ТУ */
export function requireBoss(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Нужно войти' });
  if (!isBoss(req.user.role)) return res.status(403).json({ error: 'Недостаточно прав' });
  next();
}
/** Только админ (владелец) */
export function requireOwner(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Нужно войти' });
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });
  next();
}
/** Все, кроме наблюдателя */
export function requireEditor(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Нужно войти' });
  if (!canEditRole(req.user.role)) return res.status(403).json({ error: 'У наблюдателя только просмотр' });
  next();
}

/** Может ли пользователь работать с этой точкой. null-точку (без точки) видит только админ. */
export function canLoc(user, locationId) {
  if (isBoss(user.role)) return true;
  return locationId != null && user.locationIds.includes(locationId);
}

/* ---------- простая защита от перебора ---------- */
const fails = new Map(); // key -> {n, until}
const WINDOW = 15 * 60e3, MAX = 8;
export function loginBlocked(key) {
  const f = fails.get(key);
  if (!f) return 0;
  if (Date.now() > f.until) { fails.delete(key); return 0; }
  return f.n >= MAX ? Math.ceil((f.until - Date.now()) / 60e3) : 0;
}
export function loginFailed(key) {
  const f = fails.get(key);
  if (!f || Date.now() > f.until) fails.set(key, { n: 1, until: Date.now() + WINDOW });
  else f.n++;
}
export function loginOk(key) { fails.delete(key); }
setInterval(() => { const now = Date.now(); for (const [k, f] of fails) if (now > f.until) fails.delete(k); }, 10 * 60e3).unref();
setInterval(() => { db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now()); }, 6 * 3600e3).unref();
