import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { '@shared': path.resolve(__dirname, '../shared') } },
  server: {
    fs: { allow: ['..'] },
    proxy: { '/api': 'http://localhost:8080' },
  },
  build: { target: 'es2020', sourcemap: false },
});
