import { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { useStore, sortByStatus } from './store';
import { Row } from './Row';
import { I, download, useUI } from './ui';
import { importOldJson } from './importOld';
import type { Employee } from './types';
import { POS_LABEL, empWord, evalEmp, fmt, isTrainee, isoOf, normKey, today, type Eval } from '@shared/status.js';

const FILTER_LABEL: Record<string, string> = { ok: 'в норме', warn: 'скоро истекает', danger: 'просрочено / нет', grace: 'стажёры в льготе' };
const POS_FILTER: [string, string][] = [['all', 'Все должности'], ['manager', 'Менеджеры'], ['barista', 'Баристы'], ['pizzamaker', 'Пиццамейкеры'], ['trainee', 'Стажёры']];

type Item = { e: Employee; ev: Eval };

function docPlain(d: Employee['med']) { return d.mode === 'none' ? 'не имеется' : d.mode === 'absent' ? 'отсутствует на точке' : d.date ? fmt(d.date) : '—'; }
function statusText(e: Employee, ev: Eval) {
  if (e.archived) return 'в архиве с ' + fmt(e.archivedAt);
  if (ev.problems.length) return ev.problems.join('; ');
  if (ev.g.active) return 'льгота стажёра до ' + fmt(ev.g.end!);
  return 'в норме';
}
const telDigits = (s: string) => s.replace(/[^\d]/g, '');

export function TableView() {
  const s = useStore(); const { toast } = useUI();
  const [print, setPrint] = useState<Item[] | null>(null);
  const arch = s.view === 'archive';
  const nArch = useMemo(() => s.employees.filter((e) => e.archived).length, [s.employees]);
  const showLoc = s.multiLoc || (s.isAdmin && s.employees.some((e) => e.locationId == null));

  const rows: Item[] = useMemo(() => {
    const q = normKey(s.search), qd = telDigits(s.search);
    const list = s.employees
      .filter((e) => (arch ? e.archived : !e.archived))
      .map((e) => ({ e, ev: evalEmp(e, s.settings.warnDays) }))
      .filter(({ e, ev }) => {
        if (q && !(normKey(e.fio).includes(q) || normKey(e.note).includes(q) || (qd.length >= 3 && telDigits(e.phone).includes(qd)))) return false;
        if (!arch && s.statusFilter !== 'all' && (s.statusFilter === 'grace' ? !ev.g.active : ev.worst !== s.statusFilter)) return false;
        if (s.posFilter !== 'all' && e.position !== s.posFilter) return false;
        return s.inLoc(e);
      });
    if (arch) return list.sort((a, b) => (b.e.archivedAt || '').localeCompare(a.e.archivedAt || '') || a.e.fio.localeCompare(b.e.fio, 'ru'));
    return sortByStatus(list);
  }, [s.employees, s.search, s.statusFilter, s.posFilter, s.inLoc, s.settings.warnDays, arch]);

  const desc = () => {
    const p: string[] = [];
    if (arch) p.push('архив'); else if (s.statusFilter !== 'all') p.push(FILTER_LABEL[s.statusFilter]);
    if (s.posFilter !== 'all') p.push(POS_FILTER.find((x) => x[0] === s.posFilter)![1].toLowerCase());
    if (s.locFilter !== 'all') p.push(s.locFilter === 'none' ? 'без точки' : s.locName(s.locFilter));
    if (s.search.trim()) p.push(`поиск «${s.search.trim()}»`);
    return p;
  };

  useEffect(() => {
    if (!print) return;
    const done = () => setPrint(null);
    window.addEventListener('afterprint', done);
    const t = setTimeout(() => window.print(), 50);
    return () => { clearTimeout(t); window.removeEventListener('afterprint', done); };
  }, [print]);

  function exportCsv() {
    if (!rows.length) { toast('Нечего выгружать — таблица пустая'); return; }
    const cell = (v: string) => (/[";\r\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v);
    const head = ['ФИО', 'Должность', 'Точка', 'Меддопуск до', 'Голограмма до', 'Статус', 'Дата рождения', 'Телефон', 'Заметка', 'Первая смена'];
    const lines = [head.map(cell).join(';')];
    rows.forEach(({ e, ev }) => lines.push([e.fio, POS_LABEL[e.position] || '', s.locName(e.locationId), docPlain(e.med), docPlain(e.holo), statusText(e, ev),
      e.birthday ? fmt(e.birthday) : '', e.phone ? '="' + e.phone.replace(/"/g, '') + '"' : '', e.note, e.firstShift ? fmt(e.firstShift) : ''].map(cell).join(';')));
    download(`dopuski-${isoOf(today())}.csv`, '﻿' + lines.join('\r\n'), 'text/csv;charset=utf-8');
    toast('Выгружено для Excel: ' + rows.length);
  }

  const chipOn = !arch && s.statusFilter !== 'all';
  return (
    <section className="panel">
      <div className="toolbar">
        <div className="search">{I.search}<input className="ctrl" placeholder="Поиск: ФИО, телефон, заметка…" autoComplete="off" value={s.search} onChange={(e) => s.setSearch(e.target.value)} /></div>
        <select className="ctrl pos-filter" aria-label="Фильтр по должности" value={s.posFilter} onChange={(e) => s.setPosFilter(e.target.value)}>
          {POS_FILTER.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
        {s.multiLoc && (
          <select className="ctrl pos-filter" aria-label="Фильтр по точке" value={String(s.locFilter)}
            onChange={(e) => { const v = e.target.value; s.setLocFilter(v === 'all' || v === 'none' ? v : Number(v)); }}>
            <option value="all">Все точки</option>
            {s.locations.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
            {s.isAdmin && s.active.some((e) => e.locationId == null) && <option value="none">Без точки</option>}
          </select>
        )}
        {chipOn && <span className="filter-chip on">Фильтр: {FILTER_LABEL[s.statusFilter]}<button aria-label="Сбросить фильтр" onClick={() => s.setStatusFilter('all')}>×</button></span>}
      </div>
      <div className="toolbar toolbar-2">
        <button className="btn sm toggle" aria-pressed={arch} onClick={() => s.setView(arch ? 'active' : 'archive')}>{I.archive}{arch ? '← К списку' : 'Архив' + (nArch ? ' · ' + nArch : '')}</button>
        <div className="spacer" />
        <button className="btn sm" title="Печать того, что сейчас в таблице" onClick={() => rows.length ? setPrint(rows) : toast('Нечего печатать — таблица пустая')}>{I.print}Печать</button>
        <button className="btn sm" title="Выгрузить то, что сейчас в таблице, для Excel" onClick={exportCsv}>{I.xls}Excel</button>
        <button className="btn sm" onClick={() => s.refresh().then(() => toast('Обновлено'))}>{I.refresh}Обновить</button>
      </div>
      <div className="table-wrap">
        {rows.length > 0 && (
          <table id="tbl" className={showLoc ? '' : 'no-loc'}>
            <thead><tr>
              <th className="col-spine" /><th className="t-fio">ФИО</th><th>Должность</th>{showLoc && <th>Точка</th>}<th>Меддопуск</th><th>Голограмма</th><th>Статус</th><th />
            </tr></thead>
            <tbody>{rows.map(({ e }) => <Row key={e.id} e={e} showLoc={showLoc} />)}</tbody>
          </table>
        )}
        {!rows.length && <Empty arch={arch} nArch={nArch} />}
      </div>
      {print && <PrintArea rows={print} desc={desc()} />}
    </section>
  );
}

function Empty({ arch, nArch }: { arch: boolean; nArch: number }) {
  const s = useStore(); const { ask, toast } = useUI();
  let h = 'Ничего не найдено', p = 'Под текущий фильтр или поиск никто не подходит.', add = false;
  if (arch && !nArch) { h = 'Архив пуст'; p = 'Сюда попадают уволенные — кнопка с коробкой у сотрудника. Отсюда их можно вернуть.'; }
  else if (!arch && !s.active.length) { h = 'Пока никого нет'; p = s.canEdit ? 'Добавь первого сотрудника — и он появится здесь.' : 'На твоих точках пока нет сотрудников.'; add = true; }
  return (
    <div className="empty">{I.empty}<h3>{h}</h3><p>{p}</p>
      {add && !s.offline && s.canEdit && <div className="empty-actions">
        <button className="btn primary" onClick={() => s.setTab('add')}>Добавить сотрудника</button>
        {s.me.user.role === 'admin' && !s.employees.length && <button className="btn" onClick={() => importOldJson(ask, toast, s.refresh)}>{I.up}Перенести из старой версии</button>}
      </div>}
    </div>
  );
}

function PrintArea({ rows, desc }: { rows: Item[]; desc: string[] }) {
  const s = useStore();
  const groups: { name: string; rows: Item[] }[] = [];
  if (s.multiLoc && s.locFilter === 'all') {
    s.locations.forEach((l) => { const g = rows.filter((x) => x.e.locationId === l.id); if (g.length) groups.push({ name: l.name, rows: g }); });
    const none = rows.filter((x) => x.e.locationId == null || !s.locations.some((l) => l.id === x.e.locationId));
    if (none.length) groups.push({ name: 'Без точки', rows: none });
  } else groups.push({ name: s.locFilter !== 'all' && s.locFilter !== 'none' ? s.locName(s.locFilter) : (!s.multiLoc && s.locations[0] ? s.locations[0].name : ''), rows });
  return createPortal(
    <div id="print-area" aria-hidden="true">
      <h1>Учёт допусков</h1>
      <div className="p-meta">Отчёт на {fmt(isoOf(today()))} · {rows.length} {empWord(rows.length)}{desc.length ? ' · ' + desc.join(', ') : ''}</div>
      {groups.map((g) => (
        <div key={g.name}>
          {g.name && <h2>{g.name} <span>{g.rows.length}</span></h2>}
          <table><thead><tr><th>№</th><th>ФИО</th><th>Должность</th><th>Меддопуск</th><th>Голограмма</th><th>Статус</th><th>Телефон</th></tr></thead>
            <tbody>{g.rows.map(({ e, ev }, i) => (
              <tr key={e.id} className={'p-' + (e.archived ? 'arch' : ev.worst)}>
                <td>{i + 1}</td>
                <td><b>{e.fio}</b>{e.note && <div className="p-note">{e.note}</div>}</td>
                <td>{POS_LABEL[e.position] || '—'}{isTrainee(e) && e.firstShift && <div className="p-note">1-я смена {fmt(e.firstShift)}</div>}</td>
                <td>{docPlain(e.med)}</td><td>{docPlain(e.holo)}</td><td>{statusText(e, ev)}</td><td>{e.phone}</td>
              </tr>))}
            </tbody></table>
        </div>
      ))}
    </div>,
    document.body,
  );
}
