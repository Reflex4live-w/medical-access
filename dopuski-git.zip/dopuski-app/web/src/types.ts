import type { Doc, Role } from '@shared/status.js';
export type { Role } from '@shared/status.js';
export type { Doc, DocMode, Level } from '@shared/status.js';

export interface Employee {
  id: string;
  locationId: number | null;
  fio: string;
  position: string;
  phone: string;
  note: string;
  birthday: string;
  firstShift: string;
  med: Doc;
  holo: Doc;
  archived: boolean;
  archivedAt: string;
  updatedAt: string;
  updatedBy: string | null;
}
export type EmpPatch = Partial<Pick<Employee, 'fio' | 'position' | 'phone' | 'note' | 'birthday' | 'firstShift' | 'med' | 'holo' | 'locationId'>>;

export interface Location { id: number; name: string; sort: number }
export interface Settings { warnDays: number; bdayDays: number }
export interface User {
  id: number; login: string; name: string; role: Role; notifyTime: string; locationIds: number[] | null;
}
export interface Me { user: User; locations: Location[]; settings: Settings }

export interface AdminUser {
  id: number; login: string; name: string; role: Role; active: boolean; notifyTime: string;
  createdAt: string; lastLogin: string | null; locationIds: number[]; pushDevices: number;
}
export interface AuditRow { at: string; action: string; user: string; fio?: string | null; details: unknown }

/** 'all' | id точки | 'none' (без точки) */
export type LocFilter = 'all' | 'none' | number;
export type StatusFilter = 'all' | 'ok' | 'warn' | 'danger' | 'grace';
export type Tab = 'table' | 'bdays' | 'add' | 'settings';
