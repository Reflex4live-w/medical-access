import { api } from './api';

export const pushSupported = () => 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;

function b64ToU8(s: string) {
  const pad = '='.repeat((4 - (s.length % 4)) % 4);
  const raw = atob((s + pad).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
}

export async function registerSW() {
  if (!('serviceWorker' in navigator)) return null;
  try { return await navigator.serviceWorker.register('/sw.js'); } catch { return null; }
}

export async function currentSub(): Promise<PushSubscription | null> {
  if (!pushSupported()) return null;
  const reg = await navigator.serviceWorker.getRegistration();
  return reg ? reg.pushManager.getSubscription() : null;
}

/** Подписать это устройство на пуши текущего пользователя. */
export async function enablePush(): Promise<void> {
  if (!pushSupported()) throw new Error('Этот браузер не умеет пуш-уведомления');
  if (!window.isSecureContext) throw new Error('Пуши работают только по HTTPS');
  const perm = await Notification.requestPermission();
  if (perm !== 'granted') throw new Error('Уведомления запрещены в настройках браузера');
  const reg = (await navigator.serviceWorker.getRegistration()) || (await registerSW());
  if (!reg) throw new Error('Не удалось запустить service worker');
  await navigator.serviceWorker.ready;
  const { key } = await api<{ key: string }>('/push/key');
  let sub = await reg.pushManager.getSubscription();
  if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToU8(key) });
  await api('/push/subscribe', { method: 'POST', body: { subscription: sub.toJSON() } });
}

/** Привязать существующую подписку к вошедшему пользователю (после смены аккаунта на устройстве). */
export async function resyncPush() {
  try {
    if (Notification.permission !== 'granted') return;
    const sub = await currentSub();
    if (sub) await api('/push/subscribe', { method: 'POST', body: { subscription: sub.toJSON() } });
  } catch { /* не критично */ }
}

export async function disablePush() {
  const sub = await currentSub();
  if (!sub) return;
  try { await api('/push/unsubscribe', { method: 'POST', body: { endpoint: sub.endpoint } }); } catch { /* всё равно отписываемся */ }
  await sub.unsubscribe();
}
