import { useCallback, useEffect, useRef, useState } from 'react';
import { api, ApiError } from './api';
import type { Employee, Me, StatusFilter } from './types';
import { StoreProvider, readCache, useStore } from './store';
import { BrandMark, I } from './ui';
import { Login } from './Login';
import { TableView } from './TableView';
import { BdaysView, AddView } from './Views';
import { SettingsView } from './Settings';
import { registerSW, resyncPush } from './push';
import { DOC_LOW, empWord, evalEmp, locShort, diffDays, parse, today, plural, ROLE_SHORT } from '@shared/status.js';

type Boot =
  | { state: 'loading' }
  | { state: 'login' }
  | { state: 'ready'; me: Me; employees: Employee[]; offline: boolean; lastSync: string | null; key: number };

export default function App() {
  const [boot, setBoot] = useState<Boot>({ state: 'loading' });
  const n = useRef(0);

  const load = useCallback(async () => {
    try {
      const [me, r] = await Promise.all([api<Me>('/me'), api<{ employees: Employee[] }>('/employees')]);
      setBoot({ state: 'ready', me, employees: r.employees, offline: false, lastSync: new Date().toISOString(), key: ++n.current });
      resyncPush();
    } catch (e) {
      if (e instanceof ApiError && e.status === 0) {
        const c = readCache();
        if (c) { setBoot({ state: 'ready', me: c.me, employees: c.employees, offline: true, lastSync: c.at, key: ++n.current }); return; }
      }
      setBoot({ state: 'login' });
    }
  }, []);

  useEffect(() => { registerSW(); load(); }, [load]);
  useEffect(() => {
    const on = () => setBoot({ state: 'login' });
    window.addEventListener('dopuski:unauthorized', on);
    return () => window.removeEventListener('dopuski:unauthorized', on);
  }, []);

  if (boot.state === 'loading') return <div className="boot"><span className="brand-mark"><BrandMark /></span></div>;
  if (boot.state === 'login') return <Login onDone={load} />;
  return (
    <StoreProvider key={boot.key} me={boot.me} employees={boot.employees} offline={boot.offline} lastSync={boot.lastSync} onLogout={() => setBoot({ state: 'login' })}>
      <Shell />
    </StoreProvider>
  );
}

function Shell() {
  const s = useStore();
  const tabs: [typeof s.tab, string][] = [['table', 'Таблица'], ['bdays', 'Дни рождения'], ...(s.canEdit ? [['add', 'Добавить']] as [typeof s.tab, string][] : []), ['settings', s.isAdmin ? 'Настройки и доступы' : 'Настройки']];
  return (
    <div className="app">
      <Topbar />
      {s.offline && (
        <div className="offline-bar">
          <span className="beacon" />
          <span>Нет связи с сервером — показаны данные на {s.lastSync ? new Date(s.lastSync).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—'}. Правки недоступны.</span>
          <button className="btn sm" onClick={() => s.refresh()}>{I.refresh}Повторить</button>
        </div>
      )}
      <Hero />
      <nav className="tabs" role="tablist">
        {tabs.map(([k, l]) => <button key={k} className="tab" role="tab" aria-selected={s.tab === k} onClick={() => s.setTab(k)}>{l}</button>)}
      </nav>
      <main>
        {s.tab === 'table' && <TableView />}
        {s.tab === 'bdays' && <BdaysView />}
        {s.tab === 'add' && <AddView />}
        {s.tab === 'settings' && <SettingsView />}
      </main>
    </div>
  );
}

function Topbar() {
  const s = useStore();
  const [theme, setTheme] = useState(() => document.documentElement.getAttribute('data-theme') || 'dark');
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    document.querySelector('meta[name=theme-color]')?.setAttribute('content', theme === 'light' ? '#eef1f5' : '#0e1217');
    try { localStorage.setItem('medhologram.theme', theme); } catch { /* */ }
  }, [theme]);
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 60e3); return () => clearInterval(t); }, []);
  const days = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'], mon = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
  const who = s.me.user.name || s.me.user.login;
  const role = ROLE_SHORT[s.me.user.role];
  const where = s.isAdmin ? role : role + ' · ' + (s.locations.length === 1 ? locShort(s.locations[0].name) : s.locations.length + ' ' + plural(s.locations.length, 'точка', 'точки', 'точек'));
  return (
    <header className="topbar">
      <div className="brand"><span className="brand-mark"><BrandMark /></span><span className="brand-name">Учёт допусков</span></div>
      <div className="top-right">
        <span className="today mono">{days[now.getDay()]}, {now.getDate()} {mon[now.getMonth()]}</span>
        <span className="who" title={s.me.user.login}><b>{who}</b><span>{where}</span></span>
        <button className="icon-btn" aria-label="Сменить тему" title="Сменить тему" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{I.moon}{I.sun}</button>
        <button className="icon-btn" aria-label="Выйти" title="Выйти" onClick={() => s.logout()}>{I.logout}</button>
      </div>
    </header>
  );
}

function useCountUp(to: number) {
  const [v, setV] = useState(0);
  const cur = useRef(0);
  useEffect(() => {
    const from = cur.current;
    if (from === to || window.matchMedia?.('(prefers-reduced-motion:reduce)').matches) { cur.current = to; setV(to); return; }
    const start = performance.now(); let raf = 0;
    const step = (t: number) => { const k = Math.min(1, (t - start) / 560); const x = Math.round(from + (to - from) * (1 - Math.pow(1 - k, 3))); cur.current = x; setV(x); if (k < 1) raf = requestAnimationFrame(step); };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [to]);
  return v;
}

function Stat({ f, label, n, sub }: { f: Exclude<StatusFilter, 'all'>; label: string; n: number; sub: string }) {
  const s = useStore(); const v = useCountUp(n);
  return (
    <button className={'stat stat--' + f} aria-pressed={s.statusFilter === f}
      onClick={() => { s.setStatusFilter(s.statusFilter === f ? 'all' : f); s.setView('active'); s.setTab('table'); }}>
      <span className="stat-num mono">{v}</span><span className="stat-label">{label}</span><span className="stat-sub">{sub || ' '}</span>
    </button>
  );
}

function Hero() {
  const s = useStore(); const wd = s.settings.warnDays;
  const c = { ok: 0, warn: 0, danger: 0, grace: 0 };
  let next: { left: number; fio: string; k: 'med' | 'holo' } | null = null;
  s.scope.forEach((e) => {
    const ev = evalEmp(e, wd); c[ev.worst]++; if (ev.g.active) { c.grace++; return; }
    (['med', 'holo'] as const).forEach((k) => {
      const d = e[k]; if (d.mode !== 'date') return; const dt = parse(d.date); if (!dt) return;
      const left = diffDays(dt, today()); if (left < 0) return;
      if (!next || left < next.left) next = { left, fio: e.fio || '(без имени)', k };
    });
  });
  const total = s.scope.length;
  const locLbl = s.locFilter === 'all' ? '' : s.locFilter === 'none' ? ' · без точки' : ' · ' + s.locName(s.locFilter);
  const nx = next as { left: number; fio: string; k: 'med' | 'holo' } | null;
  return (
    <section className="hero" aria-label="Сводка">
      <div className="hero-head">
        <span className="eyebrow">Сводка на сегодня</span>
        <span className="hero-sub mono">{(total ? `всего ${total} ${empWord(total)}` : 'нет данных') + locLbl}</span>
      </div>
      <div className="stats">
        <Stat f="ok" label="в норме" n={c.ok} sub={total ? 'из ' + total : ''} />
        <Stat f="warn" label="скоро истекает" n={c.warn} sub={c.warn ? `≤ ${wd} дн.` : ''} />
        <Stat f="danger" label="просрочено / нет" n={c.danger} sub={c.danger ? 'требуют действий' : ''} />
        <Stat f="grace" label="стажёры в льготе" n={c.grace} sub={c.grace ? 'без нарушений' : ''} />
      </div>
      <LocStrip />
      <div className={'ticker' + (c.danger ? ' is-alert' : !nx ? ' is-clear' : '')}>
        <span className="beacon" />
        <span>
          {c.danger ? <><b>{c.danger}</b> {empWord(c.danger)} с просрочкой или без документов — <b>требуют действий</b></>
            : nx ? <>Ближайшее истечение — <b>{nx.fio}</b>: {DOC_LOW[nx.k]} <span className="mono">{nx.left === 0 ? 'сегодня' : `через ${nx.left} дн.`}</span></>
              : total ? 'Всё спокойно — ближайших истечений нет' : 'Добавь сотрудников, чтобы видеть сводку'}
        </span>
      </div>
    </section>
  );
}

function LocStrip() {
  const s = useStore(); const wd = s.settings.warnDays;
  if (!s.multiLoc || !s.active.length) return null;
  const groups: { key: 'all' | 'none' | number; label: string; list: typeof s.active }[] = [
    { key: 'all', label: 'Все точки', list: s.active },
    ...s.locations.map((l) => ({ key: l.id, label: locShort(l.name), list: s.active.filter((e) => e.locationId === l.id) })),
  ];
  const none = s.active.filter((e) => e.locationId == null);
  if (none.length && s.isAdmin) groups.push({ key: 'none', label: 'Без точки', list: none });
  return (
    <div className="locs" aria-label="Точки">
      {groups.map((g) => {
        let d = 0, w = 0; g.list.forEach((e) => { const v = evalEmp(e, wd).worst; if (v === 'danger') d++; else if (v === 'warn') w++; });
        return (
          <button key={String(g.key)} className={'loc' + (g.key === 'none' ? ' loc-none' : '')} aria-pressed={s.locFilter === g.key}
            onClick={() => s.setLocFilter(g.key !== 'all' && s.locFilter === g.key ? 'all' : g.key)}>
            <span className="loc-name">{g.label}</span><span className="loc-n mono">{g.list.length}</span>
            {!!d && <span className="loc-b b-danger mono" title="просрочено / нет">{d}</span>}
            {!!w && <span className="loc-b b-warn mono" title="скоро истекает">{w}</span>}
            {!d && !w && !!g.list.length && <span className="loc-b b-ok" title="всё в норме">✓</span>}
          </button>
        );
      })}
    </div>
  );
}
