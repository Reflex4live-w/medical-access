import { useEffect, useState, type ReactNode } from 'react';
import { useStore } from './store';
import { api, errText } from './api';
import { I, fmtDateTime, useUI } from './ui';
import type { AdminUser, AuditRow, Settings } from './types';
import { currentSub, disablePush, enablePush, pushSupported } from './push';
import { plural, ROLE_LABEL, ROLE_SHORT, manageableRoles, hasLocations, type Role } from '@shared/status.js';

function Card({ title, sub, children, danger }: { title: string; sub?: string; children: ReactNode; danger?: boolean }) {
  return <div className={'card' + (danger ? ' card-danger' : '')}><div className="card-h"><h2>{title}</h2>{sub && <span className="sub">{sub}</span>}</div><div className="card-b">{children}</div></div>;
}

export function SettingsView() {
  const s = useStore();
  return (
    <section className="panel">
      <NotifyCard />
      <ThresholdsCard />
      {s.isAdmin && <LocationsCard />}
      {s.isAdmin && <UsersCard />}
      <AccountCard />
      {s.me.user.role === 'admin' && <AuditCard />}
    </section>
  );
}

/* ================= уведомления ================= */
function NotifyCard() {
  const s = useStore(); const { toast } = useUI();
  const [on, setOn] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [time, setTime] = useState(s.me.user.notifyTime);
  const supported = pushSupported();
  const perm = supported ? Notification.permission : 'denied';

  useEffect(() => { currentSub().then((x) => setOn(!!x)).catch(() => setOn(false)); }, []);

  async function enable() { setBusy(true); try { await enablePush(); setOn(true); toast('Уведомления включены на этом устройстве'); } catch (e) { toast(errText(e)); } setBusy(false); }
  async function disable() { setBusy(true); try { await disablePush(); setOn(false); toast('Уведомления на этом устройстве выключены'); } catch (e) { toast(errText(e)); } setBusy(false); }
  async function test() { setBusy(true); try { await api('/push/test', { method: 'POST', body: {} }); toast('Отправил — должно прийти через пару секунд'); } catch (e) { toast(errText(e)); } setBusy(false); }
  async function saveTime(v: string) {
    setTime(v); if (!/^\d\d:\d\d$/.test(v)) return;
    try { await api('/me', { method: 'PATCH', body: { notifyTime: v } }); await s.reloadMe(); toast('Сводка будет приходить в ' + v); } catch (e) { toast(errText(e)); }
  }

  let state: ReactNode, cls = '';
  if (!supported) { cls = 'warn'; state = <><b>Этот браузер не умеет пуш-уведомления.</b> На iPhone — сначала «Поделиться → На экран „Домой“», потом открой приложение с иконки.</>; }
  else if (!window.isSecureContext) { cls = 'warn'; state = <><b>Пуши работают только по HTTPS.</b> Открой приложение по адресу с https://.</>; }
  else if (perm === 'denied') { cls = 'warn'; state = <><b>Уведомления заблокированы</b> в настройках браузера для этого сайта — разреши их там.</>; }
  else if (on) { cls = 'ok'; state = <><b>Включены на этом устройстве.</b> Сводка по {s.isAdmin ? 'всем точкам' : s.locations.length === 1 ? 'твоей точке' : 'твоим точкам'} приходит каждый день в {s.me.user.notifyTime} — даже если приложение закрыто.</>; }
  else state = <>Включи, чтобы каждый день получать сводку по просрочкам и дням рождения. Работает на каждом устройстве отдельно — телефон, компьютер.</>;

  return (
    <Card title="Уведомления">
      <div className={'notice ' + cls} style={{ marginBottom: 16 }}>{I.info}<div>{state}</div></div>
      <div className="set-row"><span className="lab">На этом устройстве</span>
        {on ? <><button className="btn sm" disabled={busy} onClick={test}>{I.bell}Прислать сводку сейчас</button><button className="btn sm ghost" disabled={busy} onClick={disable}>Выключить</button></>
          : <button className="btn primary sm" disabled={busy || !supported || perm === 'denied' || s.offline} onClick={enable}>{I.bell}Включить уведомления</button>}
      </div>
      <div className="set-row"><span className="lab">Время ежедневной сводки</span>
        <input className="ctrl" type="time" value={time} onChange={(e) => saveTime(e.target.value)} disabled={s.offline} />
        <span className="desc">По времени сервера. Настройка твоя — у каждого пользователя своё.</span></div>
    </Card>
  );
}

/* ================= пороги ================= */
function ThresholdsCard() {
  const s = useStore(); const { toast } = useUI();
  const [v, setV] = useState<Settings>(s.settings);
  async function save(p: Partial<Settings>) {
    try { const r = await api<{ settings: Settings }>('/settings', { method: 'PATCH', body: p }); s.setSettings(r.settings); setV(r.settings); toast('Сохранено'); }
    catch (e) { toast(errText(e)); setV(s.settings); }
  }
  const ro = !s.isAdmin || s.offline;
  return (
    <Card title="Сроки" sub={s.isAdmin ? 'Общие для всех точек' : 'Задаёт руководство'}>
      <div className="set-row"><span className="lab">Предупреждать заранее</span>
        <span className="mono"><input className="ctrl" type="number" min={0} max={365} style={{ width: 84 }} value={v.warnDays} disabled={ro}
          onChange={(e) => setV({ ...v, warnDays: Number(e.target.value) })} onBlur={() => v.warnDays !== s.settings.warnDays && save({ warnDays: v.warnDays })} /> дн.</span>
        <span className="desc">За сколько дней до конца срока подсвечивать жёлтым.</span></div>
      <div className="set-row"><span className="lab">Напоминать о дне рождения</span>
        <span className="mono">за <input className="ctrl" type="number" min={0} max={90} style={{ width: 74 }} value={v.bdayDays} disabled={ro}
          onChange={(e) => setV({ ...v, bdayDays: Number(e.target.value) })} onBlur={() => v.bdayDays !== s.settings.bdayDays && save({ bdayDays: v.bdayDays })} /> дн.</span>
        <span className="desc">За сколько дней до ДР подсвечивать и добавлять в сводку.</span></div>
    </Card>
  );
}

/* ================= точки ================= */
function LocationsCard() {
  const s = useStore(); const { toast, ask } = useUI();
  const [name, setName] = useState('');
  const counts = (id: number) => s.employees.filter((e) => e.locationId === id && !e.archived).length;
  async function add() {
    const n = name.trim(); if (!n) return;
    try { await api('/locations', { method: 'POST', body: { name: n } }); setName(''); await s.refresh(); toast('Точка добавлена'); } catch (e) { toast(errText(e)); }
  }
  async function rename(id: number, old: string, n: string) {
    n = n.trim(); if (!n || n === old) return;
    try { await api('/locations/' + id, { method: 'PATCH', body: { name: n } }); await s.refresh(); toast('Переименовано'); } catch (e) { toast(errText(e)); await s.refresh(); }
  }
  async function del(id: number, n: string) {
    const c = s.employees.filter((e) => e.locationId === id).length;
    const ok = await ask(`Убрать точку «${n}»?`, c ? `К ней привязано ${c} ${plural(c, 'сотрудник', 'сотрудника', 'сотрудников')} (с архивом). Они останутся, но без точки. Управляющие потеряют к ней доступ.` : 'Сотрудников на ней нет.',
      [{ label: 'Убрать', value: true, kind: 'danger' }, { label: 'Отмена', value: false, kind: 'ghost' }]);
    if (!ok) return;
    try { await api('/locations/' + id, { method: 'DELETE' }); await s.refresh(); toast('Точка убрана'); } catch (e) { toast(errText(e)); }
  }
  return (
    <Card title="Точки">
      <div className="loc-list">
        {!s.locations.length && <p className="hint" style={{ margin: 0 }}>Точек пока нет — добавь первую.</p>}
        {s.locations.map((l) => (
          <div key={l.id + l.name} className="loc-row">
            <input className="ctrl" defaultValue={l.name} aria-label="Название точки" onBlur={(e) => rename(l.id, l.name, e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }} />
            <span className="loc-count mono">{counts(l.id)} чел.</span>
            <button className="row-del" title="Убрать точку" aria-label="Убрать точку" onClick={() => del(l.id, l.name)}>{I.trash}</button>
          </div>
        ))}
      </div>
      <div className="loc-add">
        <input className="ctrl" placeholder="Название новой точки" value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') add(); }} />
        <button className="btn sm" onClick={add}>{I.plus}Добавить</button>
      </div>
    </Card>
  );
}

/* ================= пользователи ================= */
function genPass() {
  const a = 'abcdefghjkmnpqrstuvwxyz23456789'; const r = crypto.getRandomValues(new Uint32Array(8));
  return Array.from(r, (x) => a[x % a.length]).join('');
}
function LocPicker({ value, onChange }: { value: number[]; onChange: (v: number[]) => void }) {
  const s = useStore();
  return (
    <div className="loc-pick">
      {s.locations.map((l) => {
        const on = value.includes(l.id);
        return <button key={l.id} type="button" className="pick" aria-pressed={on} onClick={() => onChange(on ? value.filter((x) => x !== l.id) : [...value, l.id])}>{l.name}</button>;
      })}
    </div>
  );
}
const ROLE_HINT: Record<Role, string> = {
  admin: 'Владелец системы. Может всё.',
  territorial: 'Все точки. Управляет СМС и наблюдателями, точками и сроками.',
  manager: 'Добавляет и правит сотрудников только своих точек.',
  viewer: 'Только смотрит свои точки, ничего не меняет.',
};
function UsersCard() {
  const s = useStore(); const { toast, ask } = useUI();
  const myRoles = manageableRoles(s.me.user.role);
  const blank = () => ({ login: '', name: '', password: genPass(), role: (myRoles.includes('manager') ? 'manager' : myRoles[0]) as Role, locationIds: [] as number[] });
  const [users, setUsers] = useState<AdminUser[] | null>(null);
  const [nu, setNu] = useState(blank);
  const [openNew, setOpenNew] = useState(false);
  const [created, setCreated] = useState<{ login: string; password: string } | null>(null);

  const load = () => api<{ users: AdminUser[] }>('/users').then((r) => setUsers(r.users)).catch((e) => toast(errText(e)));
  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function patch(u: AdminUser, body: Record<string, unknown>, msg?: string) {
    try { const r = await api<{ users: AdminUser[] }>('/users/' + u.id, { method: 'PATCH', body }); setUsers(r.users); if (msg) toast(msg); if (u.id === s.me.user.id) s.reloadMe(); }
    catch (e) { toast(errText(e)); load(); }
  }
  async function changeRole(u: AdminUser, role: Role) {
    if (hasLocations(role) && !u.locationIds.length) toast('Не забудь отметить точки — без них человек ничего не увидит');
    await patch(u, { role }, 'Роль: ' + ROLE_LABEL[role]);
  }
  async function create() {
    if (hasLocations(nu.role) && !nu.locationIds.length) { toast('Отметь хотя бы одну точку'); return; }
    try {
      const r = await api<{ users: AdminUser[] }>('/users', { method: 'POST', body: { ...nu, locationIds: hasLocations(nu.role) ? nu.locationIds : [] } });
      setUsers(r.users); setCreated({ login: nu.login, password: nu.password });
      setNu(blank()); setOpenNew(false);
    } catch (e) { toast(errText(e)); }
  }
  async function resetPass(u: AdminUser) {
    const p = genPass();
    const ok = await ask(`Новый пароль для ${u.name || u.login}`, `Пароль: ${p}\n\nСтарые входы на всех устройствах сбросятся. Передай пароль человеку.`, [{ label: 'Сменить', value: true, kind: 'primary' }, { label: 'Отмена', value: false, kind: 'ghost' }]);
    if (ok) { await patch(u, { password: p }); setCreated({ login: u.login, password: p }); }
  }
  async function del(u: AdminUser) {
    const ok = await ask(`Удалить ${u.name || u.login}?`, 'Аккаунт удалится, история его правок останется. Если человек может вернуться — лучше просто «Отключить».', [{ label: 'Удалить', value: true, kind: 'danger' }, { label: 'Отмена', value: false, kind: 'ghost' }]);
    if (!ok) return;
    try { const r = await api<{ users: AdminUser[] }>('/users/' + u.id, { method: 'DELETE' }); setUsers(r.users); toast('Удалён'); } catch (e) { toast(errText(e)); }
  }
  const copy = (t: string) => { navigator.clipboard?.writeText(t).then(() => toast('Скопировано')).catch(() => {}); };

  return (
    <Card title="Доступы">
      {created && (
        <div className="notice ok cred" style={{ marginBottom: 14 }}>{I.info}
          <div><b>Данные для входа</b> — передай человеку, пароль больше не покажу:<br />
            <span className="mono">{location.origin}</span><br />логин <span className="mono">{created.login}</span> · пароль <span className="mono">{created.password}</span>
            <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
              <button className="btn sm" onClick={() => copy(`Учёт допусков: ${location.origin}\nЛогин: ${created.login}\nПароль: ${created.password}`)}>Скопировать</button>
              <button className="btn sm ghost" onClick={() => setCreated(null)}>Скрыть</button>
            </div></div>
        </div>
      )}
      {!users && <p className="hint">Загружаю…</p>}
      <div className="users">
        {users?.map((u) => {
          const self = u.id === s.me.user.id;
          const can = !self && myRoles.includes(u.role);
          return (
            <div key={u.id} className={'user-row' + (u.active ? '' : ' off') + (can || self ? '' : ' locked')}>
              <div className="user-main">
                {can || self
                  ? <input className="ctrl user-name" defaultValue={u.name} placeholder="Имя" aria-label="Имя" onBlur={(e) => e.target.value.trim() !== u.name && patch(u, { name: e.target.value }, 'Сохранено')} />
                  : <div className="user-name-ro">{u.name || u.login}</div>}
                <div className="user-meta mono">
                  <span className={'role-tag role-' + u.role}>{ROLE_SHORT[u.role]}</span>
                  {' '}{u.login}{self && ' · это ты'}{!u.active && ' · отключён'}
                  {' · вход: '}{u.lastLogin ? fmtDateTime(u.lastLogin) : 'ещё не входил'}{' · пуши: '}{u.pushDevices ? u.pushDevices + ' устр.' : 'нет'}
                </div>
                {hasLocations(u.role)
                  ? (can ? <LocPicker value={u.locationIds} onChange={(v) => patch(u, { locationIds: v }, 'Точки обновлены')} />
                    : <div className="hint">{u.locationIds.map((id) => s.locName(id)).filter(Boolean).join(', ') || 'Точки не назначены'}</div>)
                  : <div className="hint">Видит все точки</div>}
              </div>
              {can && (
                <div className="user-actions">
                  <select className="ctrl" value={u.role} onChange={(e) => changeRole(u, e.target.value as Role)} aria-label="Роль">
                    {myRoles.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
                  </select>
                  <button className="btn sm" onClick={() => resetPass(u)}>Новый пароль</button>
                  <button className="btn sm ghost" onClick={() => patch(u, { active: !u.active }, u.active ? 'Отключён — войти не сможет' : 'Включён')}>{u.active ? 'Отключить' : 'Включить'}</button>
                  <button className="row-del" title="Удалить" aria-label="Удалить" onClick={() => del(u)}>{I.trash}</button>
                </div>
              )}
            </div>
          );
        })}
      </div>
      {!openNew ? <button className="btn primary sm" style={{ marginTop: 14 }} onClick={() => setOpenNew(true)}>{I.plus}Добавить доступ</button> : (
        <div className="new-user">
          <div className="grid">
            <div className="field"><label>Имя</label><input className="ctrl" placeholder="Анна Петрова" value={nu.name} onChange={(e) => setNu({ ...nu, name: e.target.value })} autoFocus /></div>
            <div className="field"><label>Логин (латиницей)</label><input className="ctrl" placeholder="anna" autoCapitalize="none" spellCheck={false} value={nu.login} onChange={(e) => setNu({ ...nu, login: e.target.value.trim() })} /></div>
            <div className="field"><label>Пароль</label><div className="doc-row"><input className="ctrl mono" value={nu.password} onChange={(e) => setNu({ ...nu, password: e.target.value })} /><button className="btn sm" type="button" title="Другой пароль" onClick={() => setNu({ ...nu, password: genPass() })}>{I.refresh}</button></div></div>
            <div className="field"><label>Роль</label>
              <select className="ctrl" value={nu.role} onChange={(e) => setNu({ ...nu, role: e.target.value as Role })}>
                {myRoles.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
              </select>
              <span className="hint">{ROLE_HINT[nu.role]}</span></div>
            {hasLocations(nu.role) && <div className="field full"><label>Точки</label><LocPicker value={nu.locationIds} onChange={(v) => setNu({ ...nu, locationIds: v })} />
              {!s.locations.length && <span className="hint">Сначала добавь точки в карточке «Точки» выше.</span>}</div>}
          </div>
          <div className="form-actions"><button className="btn primary" onClick={create}>Создать</button><button className="btn ghost" onClick={() => setOpenNew(false)}>Отмена</button></div>
        </div>
      )}
    </Card>
  );
}

/* ================= аккаунт ================= */
function AccountCard() {
  const s = useStore(); const { toast } = useUI();
  const [p, setP] = useState({ old: '', n1: '', n2: '' });
  async function change() {
    if (p.n1 !== p.n2) { toast('Новые пароли не совпадают'); return; }
    try { await api('/me/password', { method: 'POST', body: { oldPassword: p.old, newPassword: p.n1 } }); setP({ old: '', n1: '', n2: '' }); toast('Пароль изменён, другие устройства разлогинены'); }
    catch (e) { toast(errText(e)); }
  }
  return (
    <Card title="Мой аккаунт" sub={`${s.me.user.login} · ${ROLE_LABEL[s.me.user.role]}`}>
      <div className="grid">
        <div className="field"><label>Текущий пароль</label><input className="ctrl" type="password" autoComplete="current-password" value={p.old} onChange={(e) => setP({ ...p, old: e.target.value })} /></div>
        <div />
        <div className="field"><label>Новый пароль</label><input className="ctrl" type="password" autoComplete="new-password" value={p.n1} onChange={(e) => setP({ ...p, n1: e.target.value })} /></div>
        <div className="field"><label>Ещё раз</label><input className="ctrl" type="password" autoComplete="new-password" value={p.n2} onChange={(e) => setP({ ...p, n2: e.target.value })} /></div>
      </div>
      <div className="form-actions"><button className="btn" disabled={!p.old || !p.n1 || s.offline} onClick={change}>Сменить пароль</button><button className="btn ghost" onClick={() => s.logout()}>{I.logout}Выйти</button></div>
    </Card>
  );
}

/* ================= журнал ================= */
const ACT: Record<string, string> = {
  create: 'добавил(а) сотрудника', update: 'изменил(а)', archive: 'в архив', restore: 'вернул(а) из архива', purge: 'удалил(а) навсегда',
  'location.create': 'добавил(а) точку', 'location.rename': 'переименовал(а) точку', 'location.delete': 'убрал(а) точку',
  'user.create': 'создал(а) доступ', 'user.update': 'изменил(а) доступ', 'user.delete': 'удалил(а) доступ', import: 'импорт',
};
function AuditCard() {
  const { toast } = useUI();
  const [rows, setRows] = useState<AuditRow[] | null>(null);
  const load = () => api<{ audit: AuditRow[] }>('/audit?limit=300').then((r) => setRows(r.audit)).catch((e) => toast(errText(e)));
  const detail = (r: AuditRow) => {
    const d = r.details as Record<string, unknown> | null; if (!d) return '';
    if (r.action === 'update') { const N: Record<string, string> = { fio: 'ФИО', position: 'должность', phone: 'телефон', note: 'заметка', birthday: 'ДР', firstShift: '1-я смена', locationId: 'точка', med: 'меддопуск', holo: 'голограмма' }; return Object.keys(d).map((k) => N[k] || k).join(', '); }
    if (r.action === 'location.rename') return `${d.from} → ${d.to}`;
    if (r.action === 'import') return `${d.mode === 'replace' ? 'замена' : 'объединение'}: +${d.added}, обновл. ${d.updated}`;
    if (r.action === 'purge') return String(d.fio || '');
    return String(d.name || d.login || '');
  };
  return (
    <Card title="Журнал действий" sub="Кто что менял — последние 300 событий">
      {!rows ? <button className="btn sm" onClick={load}>{I.history}Показать журнал</button> : (
        <div className="audit">
          {rows.map((r, i) => (
            <div key={i} className="audit-row"><span className="mono audit-at">{fmtDateTime(r.at)}</span><b>{r.user}</b><span>{ACT[r.action] || r.action}{r.fio ? ` · ${r.fio}` : ''}</span><span className="audit-d">{detail(r)}</span></div>
          ))}
          {!rows.length && <p className="hint">Пока пусто</p>}
        </div>
      )}
    </Card>
  );
}
