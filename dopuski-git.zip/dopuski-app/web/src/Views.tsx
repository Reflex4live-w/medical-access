import { useState } from 'react';
import { useStore } from './store';
import { I, useUI } from './ui';
import type { DocMode } from './types';
import { POSITIONS, bdayInfo, bdayWhen, empWord, fmt, locShort, normKey, plural } from '@shared/status.js';

/* ================= дни рождения ================= */
export function BdaysView() {
  const s = useStore(); const bd = s.settings.bdayDays;
  const list = s.scope.map((e) => ({ e, b: bdayInfo(e) })).filter((x) => x.b.has).sort((a, b) => a.b.left! - b.b.left!);
  const miss = s.scope.filter((e) => !bdayInfo(e).has).length;
  return (
    <section className="panel">
      <div className="card">
        <div className="card-h"><h2>Ближайшие дни рождения</h2><span className="sub">{miss ? `Без даты рождения: ${miss} ${empWord(miss)}` : ''}</span></div>
        <div className="card-b">
          <div className="bday-list">
            {!list.length && <div className="bday-none">Ни у кого не указана дата рождения. Открой таблицу, нажми карандаш у сотрудника и впиши дату.</div>}
            {list.map(({ e, b }) => {
              const cls = b.left === 0 ? ' is-today' : b.left! <= bd ? ' is-soon' : '';
              return (
                <div key={e.id} className={'bday-row' + cls}>
                  <span className="bday-when mono">{bdayWhen(b.left!)}</span>
                  <span className="bday-name">{e.fio}{s.multiLoc && s.locFilter === 'all' && e.locationId != null && <span className="bday-loc">{locShort(s.locName(e.locationId))}</span>}</span>
                  <span className="bday-meta mono">{fmt(b.next!)} · {b.age} {plural(b.age!, 'год', 'года', 'лет')}</span>
                </div>
              );
            })}
          </div>
          <p className="hint" style={{ margin: '14px 0 0' }}>Дата рождения вписывается в таблице: карандаш у сотрудника — поле «ДР» под ФИО. Напоминание приходит вместе с ежедневной сводкой. Учитывается фильтр по точке.</p>
        </div>
      </div>
    </section>
  );
}

/* ================= добавление ================= */
const empty = () => ({ fio: '', position: '', locationId: '' as string, medMode: 'date' as DocMode, medDate: '', holoMode: 'date' as DocMode, holoDate: '', firstShift: '', birthday: '', phone: '', note: '' });

export function AddView() {
  const s = useStore(); const { toast, ask } = useUI();
  const defLoc = typeof s.locFilter === 'number' ? String(s.locFilter) : s.locations.length === 1 ? String(s.locations[0].id) : '';
  const [f, setF] = useState(() => ({ ...empty(), locationId: defLoc }));
  const [busy, setBusy] = useState(false);
  const up = (k: keyof ReturnType<typeof empty>, v: string) => setF((x) => ({ ...x, [k]: v }));

  if (!s.canEdit) return <section className="panel"><div className="card"><div className="card-b"><div className="notice">{I.info}<div>У наблюдателя только просмотр.</div></div></div></div></section>;
  if (!s.isAdmin && !s.locations.length) return <section className="panel"><div className="card"><div className="card-b"><div className="notice warn">{I.info}<div>К твоему аккаунту не привязана ни одна точка — попроси руководителя.</div></div></div></div></section>;

  async function add() {
    const fio = f.fio.trim();
    if (!fio) { toast('Впиши ФИО'); document.getElementById('f-fio')?.focus(); return; }
    if (!s.isAdmin && !f.locationId) { toast('Выбери точку'); return; }
    const dup = s.employees.find((x) => normKey(x.fio) === normKey(fio));
    if (dup) {
      const ok = await ask('Такой уже есть', `«${dup.fio}» ${dup.archived ? 'лежит в архиве' : 'уже в списке'}${dup.locationId != null ? ' (' + s.locName(dup.locationId) + ')' : ''}. Всё равно добавить ещё одного?`,
        [{ label: 'Добавить', value: true, kind: 'primary' }, { label: 'Отмена', value: false, kind: 'ghost' }]);
      if (!ok) return;
    }
    setBusy(true);
    const e = await s.createEmp({
      fio, position: f.position, locationId: f.locationId ? Number(f.locationId) : null, phone: f.phone.trim(), note: f.note.trim(),
      birthday: f.birthday, firstShift: f.position === 'trainee' ? f.firstShift : '',
      med: { mode: f.medMode, date: f.medMode === 'date' ? f.medDate : '' }, holo: { mode: f.holoMode, date: f.holoMode === 'date' ? f.holoDate : '' },
    });
    setBusy(false);
    if (e) { setF({ ...empty(), locationId: f.locationId }); s.setView('active'); s.setTab('table'); toast('Сотрудник добавлен'); }
  }

  const doc = (label: string, mode: DocMode, date: string, km: 'medMode' | 'holoMode', kd: 'medDate' | 'holoDate') => (
    <div className="field"><label>{label}</label><div className="doc-row">
      <select className="ctrl" value={mode} onChange={(e) => up(km, e.target.value)}><option value="date">Дата (до)</option><option value="none">Не имеется</option><option value="absent">Отсутствует на точке</option></select>
      {mode === 'date' && <input className="ctrl" type="date" value={date} onChange={(e) => up(kd, e.target.value)} />}
    </div></div>
  );

  return (
    <section className="panel">
      <div className="card"><div className="card-h"><h2>Новый сотрудник</h2><span className="sub">Остальное можно поправить прямо в таблице</span></div>
        <div className="card-b">
          {s.offline && <div className="notice warn" style={{ marginBottom: 16 }}>{I.info}<div>Нет связи с сервером — добавить сейчас не получится.</div></div>}
          <div className="grid">
            <div className="field full"><label htmlFor="f-fio">ФИО сотрудника</label><input className="ctrl" id="f-fio" placeholder="Иванов Иван Иванович" autoComplete="off" value={f.fio} onChange={(e) => up('fio', e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') add(); }} /></div>
            {(s.multiLoc || s.isAdmin) && (
              <div className="field"><label htmlFor="f-loc">Точка</label>
                <select className="ctrl" id="f-loc" value={f.locationId} onChange={(e) => up('locationId', e.target.value)}>
                  <option value="">{s.isAdmin ? 'Не указана' : 'Выбери точку'}</option>
                  {s.locations.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
                </select></div>
            )}
            <div className="field"><label htmlFor="f-pos">Должность</label>
              <select className="ctrl" id="f-pos" value={f.position} onChange={(e) => up('position', e.target.value)}>
                <option value="">Не указана</option>{POSITIONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select></div>
            {doc('Меддопуск действителен до', f.medMode, f.medDate, 'medMode', 'medDate')}
            {doc('Голограмма действительна до', f.holoMode, f.holoDate, 'holoMode', 'holoDate')}
            {f.position === 'trainee' && (
              <div className="field"><label htmlFor="f-fs">Первая смена</label><input className="ctrl" type="date" id="f-fs" value={f.firstShift} onChange={(e) => up('firstShift', e.target.value)} />
                <span className="hint">2 недели с первой смены нарушением не считаются.</span></div>
            )}
            <div className="field"><label htmlFor="f-bday">Дата рождения</label><input className="ctrl" type="date" id="f-bday" value={f.birthday} onChange={(e) => up('birthday', e.target.value)} /></div>
            <div className="field"><label htmlFor="f-phone">Телефон</label><input className="ctrl" type="tel" id="f-phone" placeholder="+7 913 000-00-00" autoComplete="off" value={f.phone} onChange={(e) => up('phone', e.target.value)} /></div>
            <div className="field full"><label htmlFor="f-note">Заметка</label><input className="ctrl" id="f-note" placeholder="Например: медкнижка на продлении, принесёт в пятницу" autoComplete="off" value={f.note} onChange={(e) => up('note', e.target.value)} /></div>
          </div>
          <div className="form-actions">
            <button className="btn primary" disabled={busy || s.offline} onClick={add}>{I.plus}{busy ? 'Добавляю…' : 'Добавить сотрудника'}</button>
            <button className="btn ghost" onClick={() => setF({ ...empty(), locationId: defLoc })}>Очистить</button>
          </div>
        </div></div>
    </section>
  );
}
