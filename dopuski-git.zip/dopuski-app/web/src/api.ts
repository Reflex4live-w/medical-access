export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) { super(message); this.status = status; }
}

/** Все запросы к серверу. Бросает ApiError (status 0 — нет сети). */
export async function api<T = unknown>(path: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch('/api' + path, {
      method: opts.method || 'GET',
      credentials: 'same-origin',
      headers: { 'x-requested-with': 'dopuski', ...(opts.body !== undefined ? { 'content-type': 'application/json' } : {}) },
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    });
  } catch {
    throw new ApiError(0, 'Нет связи с сервером');
  }
  let data: unknown = null;
  try { data = await res.json(); } catch { /* пусто */ }
  if (!res.ok) {
    const msg = (data as { error?: string } | null)?.error || `Ошибка ${res.status}`;
    if (res.status === 401) window.dispatchEvent(new Event('dopuski:unauthorized'));
    throw new ApiError(res.status, msg);
  }
  return data as T;
}

export const errText = (e: unknown) => (e instanceof Error ? e.message : String(e));
