import { useState, type FormEvent } from 'react';
import { api, errText } from './api';
import { BrandMark } from './ui';

export function Login({ onDone }: { onDone: () => void }) {
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setErr(''); setBusy(true);
    try { await api('/auth/login', { method: 'POST', body: { login: login.trim(), password } }); onDone(); }
    catch (x) { setErr(errText(x)); setBusy(false); }
  }

  return (
    <div className="login-wrap">
      <form className="login-card" onSubmit={submit}>
        <div className="login-brand"><span className="brand-mark"><BrandMark /></span><span className="brand-name">Учёт допусков</span></div>
        <p className="login-sub">Меддопуски, голограммы и стажёры по всем точкам</p>
        <div className="field"><label htmlFor="l-login">Логин</label>
          <input className="ctrl" id="l-login" autoComplete="username" autoCapitalize="none" spellCheck={false} value={login} onChange={(e) => setLogin(e.target.value)} autoFocus required /></div>
        <div className="field"><label htmlFor="l-pass">Пароль</label>
          <input className="ctrl" id="l-pass" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required /></div>
        {err && <div className="login-err" role="alert">{err}</div>}
        <button className="btn primary login-btn" disabled={busy}>{busy ? 'Вхожу…' : 'Войти'}</button>
        <p className="hint" style={{ margin: '14px 0 0', textAlign: 'center' }}>Нет доступа или забыл пароль — напиши руководителю.</p>
      </form>
    </div>
  );
}
