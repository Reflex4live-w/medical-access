import { api, errText } from './api';
import { plural } from '@shared/status.js';

type Ask = <T>(title: string, text: string | undefined, buttons: { label: string; value: T; kind?: string }[]) => Promise<T | null>;

/** Разовый перенос из старой локальной версии (.json). Только в пустую базу. */
export function importOldJson(ask: Ask, toast: (m: string) => void, done: () => Promise<void>) {
  const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'application/json,.json';
  inp.onchange = async () => {
    const f = inp.files?.[0]; if (!f) return;
    let data: unknown;
    try { data = JSON.parse(await f.text()); } catch { toast('Не тот .json — прочитать не вышло'); return; }
    const arr = Array.isArray(data) ? data : (data as { employees?: unknown[] })?.employees;
    if (!Array.isArray(arr)) { toast('В файле нет списка сотрудников'); return; }
    const ok = await ask(`Перенести ${arr.length} ${plural(arr.length, 'запись', 'записи', 'записей')}?`,
      'Сотрудники из старой версии появятся здесь, точки создадутся по названиям из файла.',
      [{ label: 'Перенести', value: true, kind: 'primary' }, { label: 'Отмена', value: false, kind: 'ghost' }]);
    if (!ok) return;
    try {
      const r = await api<{ added: number; updated: number }>('/import', { method: 'POST', body: { mode: 'merge', data } });
      await done(); toast(`Перенесено: ${r.added}`);
    } catch (e) { toast(errText(e)); }
  };
  inp.click();
}
