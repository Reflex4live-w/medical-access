import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { diffDays, parse, today } from '@shared/status.js';
import type { Doc } from './types';

/* ================= icons ================= */
const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, viewBox: '0 0 24 24' };
export const I = {
  edit: <svg {...S}><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z" /></svg>,
  done: <svg {...S} strokeWidth={2.4}><path d="M20 6 9 17l-5-5" /></svg>,
  archive: <svg {...S}><rect x="3" y="4" width="18" height="4" rx="1" /><path d="M5 8v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8M10 12h4" /></svg>,
  restore: <svg {...S}><path d="M3 12a9 9 0 1 0 3-6.7L3 8" /><path d="M3 3v5h5" /></svg>,
  trash: <svg {...S}><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" /></svg>,
  plus: <svg {...S}><path d="M12 5v14M5 12h14" /></svg>,
  search: <svg {...S}><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>,
  bell: <svg {...S}><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 0 1-3.4 0" /></svg>,
  print: <svg {...S}><path d="M6 9V3h12v6M6 18H4a1 1 0 0 1-1-1v-6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1h-2" /><rect x="6" y="14" width="12" height="7" /></svg>,
  xls: <svg {...S}><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9l-6-6Z" /><path d="M14 3v6h6M9 13l6 5M15 13l-6 5" /></svg>,
  down: <svg {...S}><path d="M12 3v12m0 0 4-4m-4 4-4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" /></svg>,
  up: <svg {...S}><path d="M12 15V3m0 0 4 4m-4-4-4 4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" /></svg>,
  info: <svg {...S}><circle cx="12" cy="12" r="9" /><path d="M12 8h.01M11 12h1v4h1" /></svg>,
  moon: <svg {...S} className="i-moon"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" /></svg>,
  sun: <svg {...S} className="i-sun"><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></svg>,
  logout: <svg {...S}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" /></svg>,
  history: <svg {...S}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>,
  empty: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M9 11H5a2 2 0 0 0-2 2v7h18v-7a2 2 0 0 0-2-2h-4M9 11V5a3 3 0 0 1 6 0v6M9 11h6" /></svg>,
  refresh: <svg {...S}><path d="M21 12a9 9 0 1 1-3-6.7L21 8" /><path d="M21 3v5h-5" /></svg>,
};

export const BrandMark = () => (
  <svg viewBox="0 0 48 48" fill="none"><rect width="48" height="48" rx="13" fill="#141a22" /><rect x="1" y="1" width="46" height="46" rx="12" stroke="#4d9fff" strokeOpacity=".35" strokeWidth="1.4" /><path d="M24 9 12 13.2v10.4c0 8.6 5.6 13.6 12 16.4 6.4-2.8 12-7.8 12-16.4V13.2L24 9Z" fill="none" stroke="#4d9fff" strokeWidth="2.6" strokeLinejoin="round" /><path d="m18.5 24 3.8 3.8L30 19.8" fill="none" stroke="#4d9fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg>
);

/* ================= small pieces ================= */
export function Chip({ lvl, children }: { lvl: string; children: ReactNode }) {
  return <span className={'chip c-' + lvl}><span className="dot" />{children}</span>;
}

export function meterOf(doc: Doc, graceActive: boolean, warnDays: number) {
  if (graceActive) return { lvl: 'grace', fill: 100, striped: false };
  if (doc.mode === 'none' || doc.mode === 'absent') return { lvl: 'danger', fill: 100, striped: true };
  const d = parse(doc.date); if (!d) return { lvl: 'danger', fill: 0, striped: false };
  const left = diffDays(d, today()); if (left < 0) return { lvl: 'danger', fill: 0, striped: false };
  return { lvl: left <= warnDays ? 'warn' : 'ok', fill: Math.max(4, Math.min(100, Math.round(left / 45 * 100))), striped: false };
}
export function Meter({ doc, grace, warnDays }: { doc: Doc; grace: boolean; warnDays: number }) {
  const m = meterOf(doc, grace, warnDays);
  return <div className={'meter m-' + m.lvl + (m.striped ? ' striped' : '')}><span style={{ width: m.fill + '%' }} /></div>;
}

/* ================= modal ================= */
export interface ModalBtn<T> { label: string; value: T; kind?: string }
interface ModalState { title: string; text?: string; buttons: ModalBtn<unknown>[]; resolve: (v: unknown) => void }
type AskFn = <T>(title: string, text: string | undefined, buttons: ModalBtn<T>[]) => Promise<T | null>;

/* ================= toast ================= */
interface ToastAction { label: string; fn: () => void }
type ToastFn = (msg: string, action?: ToastAction) => void;

const Ctx = createContext<{ ask: AskFn; toast: ToastFn } | null>(null);
export const useUI = () => { const c = useContext(Ctx); if (!c) throw new Error('UI ctx'); return c; };

export function UIProvider({ children }: { children: ReactNode }) {
  const [modal, setModal] = useState<ModalState | null>(null);
  const [toastS, setToastS] = useState<{ msg: string; action?: ToastAction; show: boolean; n: number }>({ msg: '', show: false, n: 0 });
  const timer = useRef<number | undefined>(undefined);

  const ask = useCallback<AskFn>((title, text, buttons) => new Promise((resolve) => {
    setModal({ title, text, buttons: buttons as ModalBtn<unknown>[], resolve: resolve as (v: unknown) => void });
  }), []);
  const close = (v: unknown) => { setModal((m) => { m?.resolve(v ?? null); return null; }); };

  const toast = useCallback<ToastFn>((msg, action) => {
    window.clearTimeout(timer.current);
    setToastS((t) => ({ msg, action, show: true, n: t.n + 1 }));
    timer.current = window.setTimeout(() => setToastS((t) => ({ ...t, show: false })), action ? 6000 : 2800);
  }, []);

  useEffect(() => {
    if (!modal) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') close(null); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [modal]);

  return (
    <Ctx.Provider value={{ ask, toast }}>
      {children}
      {modal && (
        <div className="modal" onMouseDown={(e) => { if (e.target === e.currentTarget) close(null); }}>
          <div className="modal-card" role="dialog" aria-modal="true">
            <h3>{modal.title}</h3>
            {modal.text && <p>{modal.text}</p>}
            <div className="modal-actions">
              {modal.buttons.map((b, i) => (
                <button key={i} className={'btn ' + (b.kind || '')} autoFocus={b.kind === 'primary' || (i === 0 && !modal.buttons.some((x) => x.kind === 'primary'))} onClick={() => close(b.value)}>{b.label}</button>
              ))}
            </div>
          </div>
        </div>
      )}
      <div id="toast" role="status" className={(toastS.show ? 'show' : '') + (toastS.action ? ' has-act' : '')}>
        <span>{toastS.msg}</span>
        {toastS.action && <button id="toast-act" onClick={() => { const f = toastS.action!.fn; setToastS((t) => ({ ...t, show: false, action: undefined })); f(); }}>{toastS.action.label}</button>}
      </div>
    </Ctx.Provider>
  );
}

/* ================= misc ================= */
export function download(name: string, content: BlobPart, type: string) {
  const blob = new Blob([content], { type }), a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
export const telHref = (p: string) => String(p || '').replace(/[^\d+]/g, '');
export function fmtDateTime(iso: string | null | undefined) {
  if (!iso) return '—';
  const d = new Date(iso.includes('T') ? iso : iso.replace(' ', 'T') + 'Z');
  if (isNaN(+d)) return iso;
  return d.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' });
}
