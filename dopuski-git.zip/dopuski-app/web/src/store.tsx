import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { api, ApiError, errText } from './api';
import type { Employee, EmpPatch, LocFilter, Location, Me, Settings, StatusFilter, Tab } from './types';
import { evalEmp, rank, isBoss, canEditRole } from '@shared/status.js';
import { useUI } from './ui';
import { disablePush } from './push';

const CACHE_KEY = 'dopuski.cache.v1', LOC_KEY = 'dopuski.locFilter';
const lsGet = (k: string) => { try { return localStorage.getItem(k); } catch { return null; } };
const lsSet = (k: string, v: string) => { try { localStorage.setItem(k, v); } catch { /* */ } };

export interface Store {
  me: Me;
  /** админ или ТУ: все точки, управление */
  isAdmin: boolean;
  /** не наблюдатель */
  canEdit: boolean;
  locations: Location[];
  locName: (id: number | null) => string;
  settings: Settings;
  employees: Employee[];
  offline: boolean;
  lastSync: string | null;
  // ui state
  tab: Tab; setTab: (t: Tab) => void;
  statusFilter: StatusFilter; setStatusFilter: (f: StatusFilter) => void;
  posFilter: string; setPosFilter: (p: string) => void;
  locFilter: LocFilter; setLocFilter: (l: LocFilter) => void;
  view: 'active' | 'archive'; setView: (v: 'active' | 'archive') => void;
  search: string; setSearch: (s: string) => void;
  editing: Set<string>; setEditing: (id: string, on: boolean) => void;
  // derived
  active: Employee[];
  scope: Employee[];
  inLoc: (e: Employee) => boolean;
  multiLoc: boolean;
  // actions
  refresh: () => Promise<void>;
  reloadMe: () => Promise<void>;
  createEmp: (data: EmpPatch) => Promise<Employee | null>;
  patchEmp: (id: string, patch: EmpPatch) => Promise<Employee | null>;
  archiveEmp: (e: Employee) => Promise<void>;
  restoreEmp: (e: Employee) => Promise<void>;
  purgeEmp: (e: Employee) => Promise<void>;
  logout: () => Promise<void>;
  setSettings: (s: Settings) => void;
}

const Ctx = createContext<Store | null>(null);
export const useStore = () => { const c = useContext(Ctx); if (!c) throw new Error('store'); return c; };

export function StoreProvider({ me: me0, employees: emps0, offline: off0, lastSync: ls0, onLogout, children }:
  { me: Me; employees: Employee[]; offline: boolean; lastSync: string | null; onLogout: () => void; children: ReactNode }) {
  const { toast } = useUI();
  const [me, setMe] = useState(me0);
  const [employees, setEmployees] = useState(emps0);
  const [offline, setOffline] = useState(off0);
  const [lastSync, setLastSync] = useState(ls0);
  const [tab, setTab] = useState<Tab>('table');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [posFilter, setPosFilter] = useState('all');
  const [locFilter, setLocFilterS] = useState<LocFilter>(() => {
    const v = lsGet(LOC_KEY); if (!v || v === 'all') return 'all'; if (v === 'none') return 'none'; const n = Number(v); return isNaN(n) ? 'all' : n;
  });
  const [view, setView] = useState<'active' | 'archive'>('active');
  const [search, setSearch] = useState('');
  const [editing, setEditingS] = useState<Set<string>>(new Set());
  const editingRef = useRef(editing); editingRef.current = editing;

  const isAdmin = isBoss(me.user.role);
  const canEdit = canEditRole(me.user.role);
  const locations = me.locations;
  const locMap = useMemo(() => new Map(locations.map((l) => [l.id, l.name])), [locations]);
  const locName = useCallback((id: number | null) => (id == null ? '' : locMap.get(id) || ''), [locMap]);
  const multiLoc = locations.length > 1;

  const setLocFilter = useCallback((l: LocFilter) => { setLocFilterS(l); lsSet(LOC_KEY, String(l)); }, []);
  // сбросить фильтр, если точки больше нет в доступе
  useEffect(() => {
    if (typeof locFilter === 'number' && !locMap.has(locFilter)) setLocFilter('all');
    if (locFilter === 'none' && !isAdmin) setLocFilter('all');
  }, [locFilter, locMap, isAdmin, setLocFilter]);

  const setEditing = useCallback((id: string, on: boolean) => {
    setEditingS((s) => { const n = new Set(s); if (on) n.add(id); else n.delete(id); return n; });
  }, []);

  const saveCache = (m: Me, e: Employee[]) => lsSet(CACHE_KEY, JSON.stringify({ userId: m.user.id, me: m, employees: e, at: new Date().toISOString() }));

  const upsert = useCallback((e: Employee) => {
    setEmployees((list) => { const i = list.findIndex((x) => x.id === e.id); if (i < 0) return [e, ...list]; const n = list.slice(); n[i] = e; return n; });
  }, []);

  const handleErr = useCallback((e: unknown) => {
    if (e instanceof ApiError && e.status === 0) { setOffline(true); toast('Нет связи с сервером — изменения не сохранены'); }
    else if (e instanceof ApiError && e.status === 401) { /* обработает App */ }
    else toast(errText(e));
  }, [toast]);

  const refresh = useCallback(async () => {
    try {
      const [m, r] = await Promise.all([api<Me>('/me'), api<{ employees: Employee[] }>('/employees')]);
      setMe(m);
      // строки, которые сейчас редактируются, не трогаем — чтобы не сбить ввод
      setEmployees((cur) => {
        const ed = editingRef.current;
        if (!ed.size) return r.employees;
        const local = new Map(cur.filter((x) => ed.has(x.id)).map((x) => [x.id, x]));
        return r.employees.map((x) => local.get(x.id) || x);
      });
      setOffline(false); setLastSync(new Date().toISOString());
      saveCache(m, r.employees);
    } catch (e) {
      if (e instanceof ApiError && e.status === 0) setOffline(true);
    }
  }, []);
  const reloadMe = useCallback(async () => { try { setMe(await api<Me>('/me')); } catch (e) { handleErr(e); } }, [handleErr]);

  // периодическое обновление + при возврате во вкладку
  useEffect(() => {
    const t = window.setInterval(() => { if (document.visibilityState === 'visible') refresh(); }, 60e3);
    const onVis = () => { if (document.visibilityState === 'visible') refresh(); };
    const onOnline = () => refresh();
    document.addEventListener('visibilitychange', onVis); window.addEventListener('online', onOnline);
    return () => { clearInterval(t); document.removeEventListener('visibilitychange', onVis); window.removeEventListener('online', onOnline); };
  }, [refresh]);
  useEffect(() => { saveCache(me, employees); }, [me, employees]);

  const createEmp = useCallback(async (data: EmpPatch) => {
    try { const r = await api<{ employee: Employee }>('/employees', { method: 'POST', body: data }); upsert(r.employee); return r.employee; }
    catch (e) { handleErr(e); return null; }
  }, [upsert, handleErr]);
  const patchEmp = useCallback(async (id: string, patch: EmpPatch) => {
    try { const r = await api<{ employee: Employee }>('/employees/' + id, { method: 'PATCH', body: patch }); upsert(r.employee); return r.employee; }
    catch (e) { handleErr(e); return null; }
  }, [upsert, handleErr]);

  const restoreEmp = useCallback(async (e: Employee) => {
    try {
      const r = await api<{ employee: Employee }>(`/employees/${e.id}/restore`, { method: 'POST', body: {} }); upsert(r.employee);
      toast(`«${e.fio}» снова в списке`, { label: 'Отменить', fn: async () => { try { upsert((await api<{ employee: Employee }>(`/employees/${e.id}/archive`, { method: 'POST', body: { date: e.archivedAt } })).employee); } catch (x) { handleErr(x); } } });
    } catch (x) { handleErr(x); }
  }, [upsert, toast, handleErr]);
  const archiveEmp = useCallback(async (e: Employee) => {
    try {
      const r = await api<{ employee: Employee }>(`/employees/${e.id}/archive`, { method: 'POST', body: {} }); upsert(r.employee);
      setEditing(e.id, false);
      toast(`«${e.fio}» — в архиве`, { label: 'Отменить', fn: async () => { try { upsert((await api<{ employee: Employee }>(`/employees/${e.id}/restore`, { method: 'POST', body: {} })).employee); } catch (x) { handleErr(x); } } });
    } catch (x) { handleErr(x); }
  }, [upsert, toast, handleErr, setEditing]);
  const purgeEmp = useCallback(async (e: Employee) => {
    try { await api('/employees/' + e.id, { method: 'DELETE' }); setEmployees((l) => l.filter((x) => x.id !== e.id)); toast('Удалён навсегда (есть в журнале)'); }
    catch (x) { handleErr(x); }
  }, [toast, handleErr]);

  const logout = useCallback(async () => {
    try { await disablePush(); } catch { /* */ }
    try { await api('/auth/logout', { method: 'POST', body: {} }); } catch { /* */ }
    try { localStorage.removeItem(CACHE_KEY); } catch { /* */ }
    onLogout();
  }, [onLogout]);

  const setSettings = useCallback((s: Settings) => setMe((m) => ({ ...m, settings: s })), []);

  const active = useMemo(() => employees.filter((e) => !e.archived), [employees]);
  const inLoc = useCallback((e: Employee) => {
    if (locFilter === 'all') return true;
    if (locFilter === 'none') return e.locationId == null;
    return e.locationId === locFilter;
  }, [locFilter]);
  const scope = useMemo(() => active.filter(inLoc), [active, inLoc]);

  const value: Store = {
    me, isAdmin, canEdit, locations, locName, settings: me.settings, employees, offline, lastSync,
    tab, setTab, statusFilter, setStatusFilter, posFilter, setPosFilter, locFilter, setLocFilter, view, setView, search, setSearch,
    editing, setEditing, active, scope, inLoc, multiLoc,
    refresh, reloadMe, createEmp, patchEmp, archiveEmp, restoreEmp, purgeEmp, logout, setSettings,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function sortByStatus(list: { e: Employee; ev: ReturnType<typeof evalEmp> }[]) {
  return list.sort((a, b) => rank(b.ev.worst) - rank(a.ev.worst) || a.e.fio.localeCompare(b.e.fio, 'ru'));
}
export function readCache(): { userId: number; me: Me; employees: Employee[]; at: string } | null {
  try { return JSON.parse(lsGet(CACHE_KEY) || 'null'); } catch { return null; }
}
