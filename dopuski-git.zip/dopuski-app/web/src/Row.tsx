import { memo, useEffect, useRef, useState } from 'react';
import type { Doc, DocMode, Employee, EmpPatch } from './types';
import { useStore } from './store';
import { Chip, I, Meter, telHref, useUI, fmtDateTime } from './ui';
import { api, errText } from './api';
import {
  DOC_LABEL, DOC_SHORT, POSITIONS, POS_LABEL, addMonths, bdayInfo, bdayWhen, evalEmp, fmt, fmtShort, isTrainee, isoOf, today,
} from '@shared/status.js';

const RENEW: [number, string][] = [[6, '+6 мес'], [12, '+1 год'], [24, '+2 года']];
const TEXT_FIELDS = new Set(['fio', 'phone', 'note']);

function docRead(d: Doc) {
  if (d.mode === 'none') return 'не имеется';
  if (d.mode === 'absent') return 'отсутствует на точке';
  if (!d.date) return 'дата не указана';
  return 'до ' + fmt(d.date);
}

function StatusCell({ e }: { e: Employee }) {
  const s = useStore(); const ev = evalEmp(e, s.settings.warnDays);
  if (e.archived) return <div className="status-cell"><Chip lvl="arch">в архиве с {fmt(e.archivedAt)}</Chip></div>;
  const b = bdayInfo(e);
  return (
    <div className="status-cell">
      <Chip lvl={ev.med.level}>{DOC_SHORT.med}: {ev.med.text}</Chip>
      <Chip lvl={ev.holo.level}>{DOC_SHORT.holo}: {ev.holo.text}</Chip>
      {ev.g.active && <Chip lvl="grace">стажёр · {ev.g.left} дн.</Chip>}
      {b.has && b.left! <= s.settings.bdayDays && <Chip lvl="bday">др {bdayWhen(b.left!)}</Chip>}
    </div>
  );
}

export const Row = memo(function Row({ e, showLoc }: { e: Employee; showLoc: boolean }) {
  const s = useStore(); const { ask } = useUI();
  const editing = s.editing.has(e.id) && !e.archived;
  const ev = evalEmp(e, s.settings.warnDays);
  const worst = e.archived ? 'arch' : ev.worst;
  const canAct = !s.offline && s.canEdit;

  if (editing) return <EditRow e={e} showLoc={showLoc} />;

  const b = bdayInfo(e);
  const bcls = e.archived ? '' : b.left === 0 ? ' is-today' : b.has && b.left! <= s.settings.bdayDays ? ' is-soon' : '';

  async function purge() {
    const ok = await ask('Удалить навсегда?', `«${e.fio}» пропадёт из базы. Снимок останется в журнале действий.`, [{ label: 'Удалить', value: true, kind: 'danger' }, { label: 'Отмена', value: false, kind: 'ghost' }]);
    if (ok) s.purgeEmp(e);
  }

  return (
    <tr data-id={e.id} data-worst={worst} className={e.archived ? 'is-arch' : undefined}>
      <td className="spine" />
      <td className="t-fio">
        <div className="fio-read">{e.fio || <span className="muted-txt">без имени</span>}</div>
        {e.phone && <div className="sub-line mono"><a className="tel" href={'tel:' + telHref(e.phone)}>{e.phone}</a></div>}
        {b.has && <div className={'sub-line mono bday-sub' + bcls}>др {fmtShort(e.birthday)}{!e.archived && ' · ' + bdayWhen(b.left!)}</div>}
        {e.note && <div className="note-line" title={e.note}>{e.note}</div>}
      </td>
      <td className="cell-pos">
        {e.position ? <span className={'pos-tag pos-' + e.position}><span className="pdot" />{POS_LABEL[e.position]}</span> : <span className="pos-tag pos-none">—</span>}
        {isTrainee(e) && e.firstShift && <div className="sub-line mono">1-я смена {fmtShort(e.firstShift)}</div>}
      </td>
      {showLoc && <td className="cell-loc">{e.locationId != null ? <span className="loc-tag">{s.locName(e.locationId)}</span> : <span className="muted-txt">—</span>}</td>}
      {(['med', 'holo'] as const).map((k) => (
        <td key={k} className="cell-doc" data-l={k === 'med' ? 'Меддопуск' : 'Голограмма'}>
          <div className={'doc-read' + (e[k].mode === 'date' && !e[k].date ? ' muted' : '')}>
            <span className="doc-val mono">{docRead(e[k])}</span>
            <Meter doc={e[k]} grace={!!ev.g.active} warnDays={s.settings.warnDays} />
          </div>
        </td>
      ))}
      <td className="status-td"><StatusCell e={e} /></td>
      <td className="actions">
        {canAct && !e.archived && <>
          <button className="row-edit" title="Редактировать" aria-label="Редактировать" onClick={() => s.setEditing(e.id, true)}>{I.edit}</button>
          <button className="row-del row-arch" title="Уволен — в архив" aria-label="В архив" onClick={() => s.archiveEmp(e)}>{I.archive}</button>
        </>}
        {canAct && e.archived && <>
          <button className="row-edit" title="Вернуть из архива" aria-label="Вернуть" onClick={() => s.restoreEmp(e)}>{I.restore}</button>
          {s.isAdmin && <button className="row-del" title="Удалить навсегда" aria-label="Удалить навсегда" onClick={purge}>{I.trash}</button>}
        </>}
        {!canAct && s.offline && <span className="muted-txt" title="Нет связи">—</span>}
      </td>
    </tr>
  );
});

function EditRow({ e, showLoc }: { e: Employee; showLoc: boolean }) {
  const s = useStore(); const { toast, ask } = useUI();
  const [d, setD] = useState<Employee>(e);
  const pending = useRef<EmpPatch>({});
  const timer = useRef<number | undefined>(undefined);
  const inflight = useRef<Promise<unknown>>(Promise.resolve());
  const fioRef = useRef<HTMLInputElement>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => { fioRef.current?.focus(); }, []);
  useEffect(() => () => { window.clearTimeout(timer.current); void flush(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  function flush() {
    window.clearTimeout(timer.current);
    const p = pending.current; pending.current = {};
    if (!Object.keys(p).length) return inflight.current;
    if ('fio' in p && !String(p.fio).trim()) { toast('ФИО не может быть пустым'); return inflight.current; }
    setSaving(true);
    inflight.current = inflight.current.then(() => s.patchEmp(e.id, p)).finally(() => setSaving(false));
    return inflight.current;
  }
  function set<K extends keyof EmpPatch>(key: K, value: EmpPatch[K]) {
    setD((x) => ({ ...x, [key]: value }) as Employee);
    pending.current = { ...pending.current, [key]: value };
    window.clearTimeout(timer.current);
    if (TEXT_FIELDS.has(key)) timer.current = window.setTimeout(flush, 700);
    else flush();
  }
  async function done() { await flush(); s.setEditing(e.id, false); }
  function setDoc(k: 'med' | 'holo', doc: Doc) { set(k, doc); }
  function renew(k: 'med' | 'holo', m: number) {
    const date = isoOf(addMonths(today(), m)); setDoc(k, { mode: 'date', date }); toast(`${DOC_LABEL[k]} → до ${fmt(date)}`);
  }
  async function history() {
    try {
      const r = await api<{ history: { at: string; action: string; user: string; details: Record<string, [unknown, unknown]> | null }[] }>(`/employees/${e.id}/history`);
      const names: Record<string, string> = { fio: 'ФИО', position: 'должность', phone: 'телефон', note: 'заметка', birthday: 'ДР', firstShift: '1-я смена', locationId: 'точка', med: 'меддопуск', holo: 'голограмма' };
      const act: Record<string, string> = { create: 'добавил(а)', archive: 'в архив', restore: 'вернул(а) из архива', update: 'изменил(а)' };
      const val = (k: string, v: unknown) => k === 'locationId' ? (s.locName(v as number) || 'без точки') : k === 'position' ? (POS_LABEL[v as string] || '—')
        : typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) ? fmt(v) : v === 'none' ? 'не имеется' : v === 'absent' ? 'отсутствует' : (v as string) || '—';
      const lines = r.history.slice(0, 15).map((h) => {
        let t = `${fmtDateTime(h.at)} · ${h.user} · ${act[h.action] || h.action}`;
        if (h.action === 'update' && h.details) t += ': ' + Object.entries(h.details).map(([k, [a, b]]) => `${names[k] || k} ${val(k, a)} → ${val(k, b)}`).join('; ');
        return t;
      });
      await ask('История: ' + e.fio, lines.join('\n') || 'Пока пусто', [{ label: 'Закрыть', value: true, kind: 'primary' }]);
    } catch (x) { toast(errText(x)); }
  }

  const ev = evalEmp(d, s.settings.warnDays);
  const docEdit = (k: 'med' | 'holo') => (
    <td className="cell-doc" data-l={DOC_LABEL[k]}>
      <div className="doc-row">
        <select value={d[k].mode} onChange={(x) => setDoc(k, { ...d[k], mode: x.target.value as DocMode })} aria-label={DOC_LABEL[k]}>
          <option value="date">Дата</option><option value="none">Не имеется</option><option value="absent">Отсутствует</option>
        </select>
        {d[k].mode === 'date' && <input type="date" value={d[k].date} onChange={(x) => setDoc(k, { mode: 'date', date: x.target.value })} aria-label={DOC_LABEL[k] + ' до'} />}
      </div>
      <Meter doc={d[k]} grace={!!ev.g.active} warnDays={s.settings.warnDays} />
      <div className="renew" title="Новый срок считается от сегодняшней даты">
        <span className="renew-lab">продлить от сегодня</span>
        {RENEW.map(([m, l]) => <button key={m} type="button" onClick={() => renew(k, m)}>{l}</button>)}
      </div>
    </td>
  );

  return (
    <tr data-id={e.id} data-worst={ev.worst} className="editing"
      onKeyDown={(x) => { if ((x.key === 'Enter' || x.key === 'Escape') && (x.target as HTMLElement).tagName === 'INPUT') { x.preventDefault(); done(); } }}>
      <td className="spine" />
      <td className="t-fio">
        <input ref={fioRef} className="fio-inp" value={d.fio} placeholder="ФИО" onChange={(x) => set('fio', x.target.value)} />
        <div className="fio-extra">
          <label className="mini"><span>ДР</span><input type="date" value={d.birthday} onChange={(x) => set('birthday', x.target.value)} /></label>
          <label className="mini"><span>Тел.</span><input type="tel" value={d.phone} placeholder="+7…" onChange={(x) => set('phone', x.target.value)} /></label>
          <label className="mini wide"><span>Заметка</span><input value={d.note} placeholder="—" onChange={(x) => set('note', x.target.value)} /></label>
        </div>
        <div className="edit-meta">
          {saving ? 'сохраняю…' : e.updatedBy ? `изм. ${e.updatedBy}, ${fmtDateTime(e.updatedAt)}` : 'сохраняется само'}
          <button type="button" className="link-btn" onClick={history}>{I.history}история</button>
        </div>
      </td>
      <td className="cell-pos">
        <div className="pos-box">
          <select className="pos-select" value={d.position} onChange={(x) => set('position', x.target.value)} aria-label="Должность">
            <option value="">Не указана</option>{POSITIONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
          {d.position === 'trainee' && <input type="date" className="pos-firstshift" title="Первая смена" value={d.firstShift} onChange={(x) => set('firstShift', x.target.value)} />}
        </div>
      </td>
      {showLoc && <td className="cell-loc">
        <select className="pos-select loc-select" value={d.locationId ?? ''} onChange={(x) => set('locationId', x.target.value === '' ? null : Number(x.target.value))} aria-label="Точка">
          {(s.isAdmin || d.locationId == null) && <option value="">Не указана</option>}
          {s.locations.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
        </select>
      </td>}
      {docEdit('med')}
      {docEdit('holo')}
      <td className="status-td"><StatusCell e={d} /></td>
      <td className="actions">
        <button className="row-done" title="Готово" aria-label="Готово" onClick={done}>{I.done}</button>
        <button className="row-del row-arch" title="Уволен — в архив" aria-label="В архив" onClick={async () => { await flush(); s.archiveEmp(e); }}>{I.archive}</button>
      </td>
    </tr>
  );
}
