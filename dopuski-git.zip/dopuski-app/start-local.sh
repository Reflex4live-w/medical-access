#!/usr/bin/env bash
# Локальный запуск на macOS / Linux:  bash start-local.sh
set -e
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Не найден Node.js — установите версию LTS с https://nodejs.org"; exit 1; }
[ -d server/node_modules ] || (echo "[1/3] Зависимости сервера..."; cd server && npm install --no-audit --no-fund)
echo "[2/3] Собираю интерфейс..."; (cd web && { [ -d node_modules ] || npm install --no-audit --no-fund; } && npm run build)
export PORT=8080 DATA_DIR="$PWD/local-data" ADMIN_LOGIN=admin ADMIN_PASSWORD=admin123 ADMIN_NAME=Администратор TZ=Asia/Novosibirsk
echo; echo "  [3/3] Откройте http://localhost:8080  (логин admin / пароль admin123). Остановка — Ctrl+C"; echo
(sleep 2; command -v open >/dev/null && open http://localhost:8080 || xdg-open http://localhost:8080 >/dev/null 2>&1 || true) &
exec node server/src/index.js
