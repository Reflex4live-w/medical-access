#!/usr/bin/env bash
# Установка «Учёта допусков» на чистый Ubuntu 22.04/24.04 (или Debian 12).
# Запуск:  sudo bash install.sh
set -euo pipefail
cd "$(dirname "$0")"

say(){ printf '\n\033[1;34m▸ %s\033[0m\n' "$*"; }
die(){ printf '\n\033[1;31m✖ %s\033[0m\n' "$*"; exit 1; }
[ "$(id -u)" = 0 ] || die "Запустите через sudo: sudo bash install.sh"

# ---------- 1. Docker ----------
if ! command -v docker >/dev/null 2>&1; then
  say "Ставлю Docker из репозитория дистрибутива"
  apt-get update -qq
  apt-get install -y -qq docker.io >/dev/null
  apt-get install -y -qq docker-compose-v2 >/dev/null 2>&1 || apt-get install -y -qq docker-compose-plugin >/dev/null 2>&1 || true
  systemctl enable --now docker
fi
docker compose version >/dev/null 2>&1 || die "Нет docker compose. Установите пакет docker-compose-v2 (или docker-compose-plugin) и запустите ещё раз."

# ---------- 2. Зеркала Docker Hub (в РФ он часто отвечает 403) ----------
if [ ! -f /etc/docker/daemon.json ]; then
  say "Прописываю зеркала Docker Hub"
  cat > /etc/docker/daemon.json <<'JSON'
{
  "registry-mirrors": [
    "https://dockerhub.timeweb.cloud",
    "https://mirror.gcr.io",
    "https://huecker.io"
  ],
  "log-driver": "json-file",
  "log-opts": { "max-size": "10m", "max-file": "3" }
}
JSON
  systemctl restart docker
fi

# ---------- 3. Настройки ----------
if [ ! -f .env ]; then
  say "Первичная настройка"
  IP=$(curl -fsS4 --max-time 5 https://ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
  DEF_DOMAIN="$(echo "$IP" | tr . -).sslip.io"
  read -rp "Домен (A-запись на $IP) [$DEF_DOMAIN]: " DOMAIN; DOMAIN=${DOMAIN:-$DEF_DOMAIN}
  read -rp "Логин админа [admin]: " AL; AL=${AL:-admin}
  read -rp "Имя админа [Администратор]: " AN; AN=${AN:-Администратор}
  while :; do read -rsp "Пароль админа (от 6 символов): " AP; echo; [ ${#AP} -ge 6 ] && break; echo "Коротковато"; done
  read -rp "E-mail для пуш-сервисов [admin@$DOMAIN]: " EM; EM=${EM:-admin@$DOMAIN}
  cat > .env <<ENV
DOMAIN=$DOMAIN
ADMIN_LOGIN=$AL
ADMIN_PASSWORD=$AP
ADMIN_NAME=$AN
VAPID_SUBJECT=mailto:$EM
TZ=Asia/Novosibirsk
ENV
  chmod 600 .env
fi
mkdir -p data && chown 1000:1000 data   # внутри контейнера работает пользователь node (uid 1000)

# ---------- 4. Запуск ----------
say "Собираю и запускаю (первый раз — несколько минут)"
docker compose up -d --build

DOMAIN=$(grep ^DOMAIN= .env | cut -d= -f2-)
say "Готово"
echo "  Адрес: https://$DOMAIN"
echo "  Логи:   docker compose logs -f app"
echo "  Если сертификат не выдаётся — проверьте, что порты 80 и 443 открыты и домен указывает на этот сервер."
