// Общая логика статусов — используется и сервером (пуши), и фронтом.
// Даты — строки 'YYYY-MM-DD', считаем в локальном времени.

export const GRACE_DAYS = 14;

export const POSITIONS = [
  ['manager', 'Менеджер'],
  ['barista', 'Бариста'],
  ['pizzamaker', 'Пиццамейкер'],
  ['trainee', 'Стажёр'],
];
export const POS_LABEL = Object.fromEntries(POSITIONS);
export const DOC_LABEL = { med: 'Меддопуск', holo: 'Голограмма' };
export const DOC_SHORT = { med: 'МД', holo: 'ГГ' };
export const DOC_LOW = { med: 'меддопуск', holo: 'голограмма' };

export function validPos(p) { return p === 'manager' || p === 'barista' || p === 'pizzamaker' || p === 'trainee'; }
export function validMode(m) { return m === 'date' || m === 'none' || m === 'absent'; }
export function isIsoDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = parse(s);
  return !!d && isoOf(d) === s && d.getFullYear() > 1900 && d.getFullYear() < 2200;
}

export function today() { const d = new Date(); d.setHours(0, 0, 0, 0); return d; }
export function parse(s) {
  if (!s) return null;
  const p = String(s).split('-');
  if (p.length !== 3) return null;
  const d = new Date(+p[0], +p[1] - 1, +p[2]);
  d.setHours(0, 0, 0, 0);
  return isNaN(+d) ? null : d;
}
export function mkDay(y, m, dd) {
  let x = new Date(y, m, dd);
  if (x.getMonth() !== ((m % 12) + 12) % 12) x = new Date(y, m + 1, 0); // 31-е / 29.02 → последний день месяца
  x.setHours(0, 0, 0, 0);
  return x;
}
export function addDays(d, n) { const x = new Date(d); x.setDate(x.getDate() + n); return x; }
export function addMonths(d, n) { const tm = d.getMonth() + n; return mkDay(d.getFullYear() + Math.floor(tm / 12), ((tm % 12) + 12) % 12, d.getDate()); }
export function diffDays(a, b) { return Math.round((a - b) / 86400000); }
export function isoOf(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
export function fmt(s) { const d = parse(s); if (!d) return '—'; return String(d.getDate()).padStart(2, '0') + '.' + String(d.getMonth() + 1).padStart(2, '0') + '.' + d.getFullYear(); }
export function fmtShort(s) { const d = parse(s); if (!d) return ''; return String(d.getDate()).padStart(2, '0') + '.' + String(d.getMonth() + 1).padStart(2, '0'); }
export function plural(n, a, b, c) { n = Math.abs(n) % 100; const d = n % 10; if (n > 10 && n < 20) return c; if (d > 1 && d < 5) return b; if (d === 1) return a; return c; }
export function empWord(n) { return plural(n, 'сотрудник', 'сотрудника', 'сотрудников'); }
export function normKey(s) { return String(s ?? '').toLowerCase().replace(/ё/g, 'е').replace(/\s+/g, ' ').trim(); }

export function isTrainee(e) { return e.position === 'trainee'; }

export function graceInfo(e) {
  if (!isTrainee(e)) return { active: false };
  const fs = parse(e.firstShift);
  if (!fs) return { active: false, needShift: true };
  const end = addDays(fs, GRACE_DAYS), left = diffDays(end, today());
  return { active: left >= 0, left, end: isoOf(end), needShift: false };
}

export function docStatus(doc, g, warnDays) {
  if (g.active) return { level: 'grace', text: 'льгота стажёра' };
  if (doc.mode === 'none') return { level: 'danger', text: 'не имеется' };
  if (doc.mode === 'absent') return { level: 'danger', text: 'отсутствует' };
  const d = parse(doc.date);
  if (!d) return { level: 'danger', text: 'нет даты' };
  const left = diffDays(d, today());
  if (left < 0) return { level: 'danger', text: 'просрочен ' + (-left) + ' дн.' };
  if (left <= warnDays) return { level: 'warn', text: left === 0 ? 'истекает сегодня' : 'через ' + left + ' дн.' };
  return { level: 'ok', text: 'до ' + fmt(doc.date) };
}

export function rank(l) { return l === 'danger' ? 3 : l === 'warn' ? 2 : l === 'grace' ? 1 : 0; }

export function evalEmp(e, warnDays) {
  const g = graceInfo(e), med = docStatus(e.med, g, warnDays), holo = docStatus(e.holo, g, warnDays);
  let worst = 'ok';
  [med.level, holo.level].forEach((l) => { if (rank(l) > rank(worst) && l !== 'grace') worst = l; });
  const problems = [];
  if (med.level === 'danger' || med.level === 'warn') problems.push(DOC_LABEL.med + ' — ' + med.text);
  if (holo.level === 'danger' || holo.level === 'warn') problems.push(DOC_LABEL.holo + ' — ' + holo.text);
  if (isTrainee(e) && g.needShift) { if (worst === 'ok') worst = 'warn'; problems.push('стажёр без даты первой смены'); }
  return { g, med, holo, worst, problems };
}

export function bdayInfo(e) {
  const d = parse(e.birthday);
  if (!d) return { has: false };
  const t = today();
  let nxt = mkDay(t.getFullYear(), d.getMonth(), d.getDate());
  if (nxt < t) nxt = mkDay(t.getFullYear() + 1, d.getMonth(), d.getDate());
  return { has: true, left: diffDays(nxt, t), age: nxt.getFullYear() - d.getFullYear(), next: isoOf(nxt) };
}
export function bdayWhen(l) { return l === 0 ? 'сегодня' : l === 1 ? 'завтра' : 'через ' + l + ' дн.'; }

export function locShort(n) { return n ? String(n).split(',')[0].trim() : ''; }

/** Текст сводки для уведомления. list — активные сотрудники с полем locationName. */
export function buildSummary(list, settings, opts = {}) {
  const warnDays = settings.warnDays, bdDays = settings.bdayDays;
  const showLoc = opts.showLoc !== false;
  const withLoc = (e) => (e.fio || 'без имени') + (showLoc && e.locationName ? ' (' + locShort(e.locationName) + ')' : '');
  const probs = [];
  list.forEach((e) => { const ev = evalEmp(e, warnDays); if (ev.problems.length) probs.push({ e, items: ev.problems, worst: ev.worst }); });
  probs.sort((a, b) => (a.worst === 'danger' ? 0 : 1) - (b.worst === 'danger' ? 0 : 1));
  const bd = list.map((e) => ({ e, b: bdayInfo(e) })).filter((x) => x.b.has && x.b.left <= bdDays).sort((a, b) => a.b.left - b.b.left);
  if (!probs.length && !bd.length) return null;
  const bdLines = bd.map((x) => '🎂 ' + withLoc(x.e) + ' — ' + bdayWhen(x.b.left) + ' (' + x.b.age + ' ' + plural(x.b.age, 'год', 'года', 'лет') + ')');
  if (!probs.length) {
    return { title: bd.length === 1 ? 'Скоро день рождения' : 'Скоро дни рождения (' + bd.length + ')', body: bdLines.slice(0, 5).join('\n'), problems: 0 };
  }
  const n = probs.length;
  const title = n === 1 ? '1 сотрудник требует внимания' : n + ' ' + plural(n, 'сотрудник требует', 'сотрудника требуют', 'сотрудников требуют') + ' внимания';
  let body = probs.slice(0, 4).map((x) => withLoc(x.e) + ': ' + x.items.join('; ')).join('\n');
  if (n > 4) body += '\n…и ещё ' + (n - 4);
  if (bdLines.length) body += '\n' + bdLines.slice(0, 3).join('\n');
  return { title, body, problems: n };
}

/* ================= роли ================= */
// admin — владелец (один), territorial — ТУ, manager — СМС (своя точка), viewer — наблюдатель (только смотреть)
export const ROLES = ['admin', 'territorial', 'manager', 'viewer'];
export const ROLE_LABEL = { admin: 'Админ', territorial: 'Территориальный управляющий', manager: 'СМС', viewer: 'Наблюдатель' };
export const ROLE_SHORT = { admin: 'админ', territorial: 'ТУ', manager: 'СМС', viewer: 'наблюдатель' };
export const ROLE_RANK = { admin: 4, territorial: 3, manager: 2, viewer: 1 };
export function isRole(r) { return ROLES.includes(r); }
/** Видит все точки и управляет системой */
export function isBoss(role) { return role === 'admin' || role === 'territorial'; }
/** Может что-то менять в сотрудниках */
export function canEditRole(role) { return role !== 'viewer'; }
/** Кого может заводить/менять этот пользователь: только роли строго ниже своей, админа — никто */
export function manageableRoles(role) {
  if (role === 'admin') return ['territorial', 'manager', 'viewer'];
  if (role === 'territorial') return ['manager', 'viewer'];
  return [];
}
/** Роли, которым назначаются конкретные точки */
export function hasLocations(role) { return role === 'manager' || role === 'viewer'; }
