export type Level = 'ok' | 'warn' | 'danger' | 'grace';
export type DocMode = 'date' | 'none' | 'absent';
export interface Doc { mode: DocMode; date: string }
export interface EmpLike { fio: string; position: string; birthday: string; firstShift: string; med: Doc; holo: Doc; locationName?: string }
export interface Grace { active: boolean; left?: number; end?: string; needShift?: boolean }
export interface DocSt { level: Level; text: string }
export interface Eval { g: Grace; med: DocSt; holo: DocSt; worst: 'ok' | 'warn' | 'danger'; problems: string[] }
export interface Bday { has: boolean; left?: number; age?: number; next?: string }

export const GRACE_DAYS: number;
export const POSITIONS: [string, string][];
export const POS_LABEL: Record<string, string>;
export const DOC_LABEL: { med: string; holo: string };
export const DOC_SHORT: { med: string; holo: string };
export const DOC_LOW: { med: string; holo: string };
export function validPos(p: string): boolean;
export function validMode(m: string): boolean;
export function isIsoDate(s: unknown): boolean;
export function today(): Date;
export function parse(s: string | null | undefined): Date | null;
export function mkDay(y: number, m: number, d: number): Date;
export function addDays(d: Date, n: number): Date;
export function addMonths(d: Date, n: number): Date;
export function diffDays(a: Date, b: Date): number;
export function isoOf(d: Date): string;
export function fmt(s: string | null | undefined): string;
export function fmtShort(s: string | null | undefined): string;
export function plural(n: number, a: string, b: string, c: string): string;
export function empWord(n: number): string;
export function normKey(s: unknown): string;
export function isTrainee(e: { position: string }): boolean;
export function graceInfo(e: EmpLike): Grace;
export function docStatus(doc: Doc, g: Grace, warnDays: number): DocSt;
export function rank(l: string): number;
export function evalEmp(e: EmpLike, warnDays: number): Eval;
export function bdayInfo(e: { birthday: string }): Bday;
export function bdayWhen(l: number): string;
export function locShort(n: string | null | undefined): string;
export function buildSummary(list: EmpLike[], settings: { warnDays: number; bdayDays: number }, opts?: { showLoc?: boolean }): { title: string; body: string; problems: number } | null;
export type Role = 'admin' | 'territorial' | 'manager' | 'viewer';
export const ROLES: Role[];
export const ROLE_LABEL: Record<Role, string>;
export const ROLE_SHORT: Record<Role, string>;
export const ROLE_RANK: Record<Role, number>;
export function isRole(r: unknown): r is Role;
export function isBoss(role: string): boolean;
export function canEditRole(role: string): boolean;
export function manageableRoles(role: string): Role[];
export function hasLocations(role: string): boolean;
