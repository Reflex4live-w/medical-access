@echo off
chcp 65001 >nul
title Учёт допусков — локально
cd /d "%~dp0"

where node >nul 2>nul || (
  echo.
  echo  Не найден Node.js. Скачайте версию LTS с https://nodejs.org , установите и запустите этот файл ещё раз.
  echo.
  pause & exit /b 1
)

if not exist server\node_modules (
  echo [1/3] Ставлю зависимости сервера...
  pushd server & call npm install --no-audit --no-fund || (popd & pause & exit /b 1) & popd
)
echo [2/3] Собираю интерфейс...
pushd web
if not exist node_modules (call npm install --no-audit --no-fund || (popd & pause & exit /b 1))
call npm run build || (popd & pause & exit /b 1)
popd

set PORT=8080
set DATA_DIR=%~dp0local-data
set ADMIN_LOGIN=admin
set ADMIN_PASSWORD=admin123
set ADMIN_NAME=Администратор
set TZ=Asia/Novosibirsk

echo.
echo  [3/3] Запуск. Откройте в браузере:  http://localhost:8080
echo        Логин: admin   Пароль: admin123
echo        Остановка — закройте это окно.
echo.
start "" http://localhost:8080
node server\src\index.js
pause
